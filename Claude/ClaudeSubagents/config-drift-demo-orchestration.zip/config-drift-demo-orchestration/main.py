#!/usr/bin/env python
"""CLI entry point for the supervisor/subagent orchestration demo.

Usage:
    python main.py                     interactive mode — type a task, get an answer
    python main.py --demo              run one preset task that exercises all 4 subagents
    python main.py "your task here"    run a single task and exit
"""

import sys

# Windows consoles default to a legacy codepage (cp1252) that can't encode
# characters like → or — that models routinely produce. Force UTF-8 for
# stdout/stderr so printing model output never crashes.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from orchestrator import supervisor  # noqa: E402  (import after the stdout reconfigure above)
from orchestrator.log_utils import divider, log, setup as setup_logging  # noqa: E402

DEMO_TASK = (
    "Using the sample sales dataset: find total revenue by region for Q1 (Jan-Mar), "
    "write a Python script that computes month-over-month revenue growth for the "
    "North region, analyze the growth trend and give a one-paragraph strategic "
    "recommendation, and save a short markdown summary report of all of this to disk."
)


def main():
    args = sys.argv[1:]

    if args and args[0] == "--demo":
        task = DEMO_TASK
    elif args:
        task = " ".join(args)
    else:
        print("Supervisor + Subagent Orchestration Demo")
        print("Type a task for the supervisor (or 'demo' to run the preset demo task).\n")
        task = input("> ").strip()
        if task.lower() == "demo":
            task = DEMO_TASK
        if not task:
            print("No task given, exiting.")
            return

    log_path = setup_logging("run")
    print(f"Logging this run to: {log_path}\n")

    log(f"TASK: {task}")
    divider("#")
    try:
        result = supervisor.run(task)
    except Exception as exc:
        if "DefaultCredentialsError" in type(exc).__name__ or "could not automatically determine credentials" in str(exc):
            print(
                "ERROR: No Google Cloud credentials found.\n"
                "Run: gcloud auth application-default login\n"
                "and make sure GCP_PROJECT_ID / CLAUDE_VERTEX_REGION are set correctly.",
                file=sys.stderr,
            )
            sys.exit(1)
        raise

    divider("#")
    log("FINAL ANSWER")
    divider("#")
    log(result)


if __name__ == "__main__":
    main()
