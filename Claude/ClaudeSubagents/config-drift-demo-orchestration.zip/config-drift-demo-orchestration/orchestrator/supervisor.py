"""Supervisor — analyzes an incoming task, delegates pieces of it to the four
specialized subagents (data, code, docs, analysis), and synthesizes their
results into one final answer.

Each subagent is exposed to the supervisor as a tool. When the supervisor
calls one of these tools, we run that subagent to completion (its own Claude
call + its own tool-use loop) and feed its final text back as the tool
result. This is the standard "agents as tools" pattern for hierarchical
multi-agent systems.
"""

from anthropic import AnthropicVertex

import config
from agents import analysis_agent, code_agent, data_agent, docs_agent
from orchestrator.log_utils import divider, log, timed, truncate

# Human-readable names for the log/console, keyed by delegation tool name.
_AGENT_LABELS = {
    "delegate_to_data_agent": "Data Agent",
    "delegate_to_code_agent": "Code Agent",
    "delegate_to_docs_agent": "Docs Agent",
    "delegate_to_analysis_agent": "Analysis Agent",
}

client = AnthropicVertex(project_id=config.PROJECT_ID, region=config.REGION)

SYSTEM_PROMPT = """You are the Supervisor of a small team of specialized agents. Your job is to:

1. Analyze the user's task and break it into subtasks.
2. Delegate each subtask to the right specialist using the delegation tools available
   to you. You may call multiple agents, and you may call the same agent more than
   once if the task has multiple parts for it.
3. When delegating to the Analysis Agent, pass along any concrete numbers the Data
   Agent already found — don't make it re-derive them.
4. Once you have enough information back from your agents, synthesize it into one
   clear, well-organized final answer for the user. Do not just concatenate the
   agents' raw output — write a coherent summary that pulls the pieces together.

Available specialists:
- Data Agent: queries and aggregates the sample sales dataset (revenue/units by
  region/month).
- Code Agent: writes and executes Python code, verifying it actually runs.
- Docs Agent: writes markdown documentation/reports to disk.
- Analysis Agent: computes statistics and produces interpretive/strategic conclusions.

Only delegate to agents that are actually relevant to the task — don't invoke all
four just because they exist."""

DELEGATION_TOOLS = [
    {
        "name": "delegate_to_data_agent",
        "description": (
            "Delegate a data retrieval/aggregation task to the Data Agent. Use this "
            "for anything requiring numbers from the sample sales dataset (revenue, "
            "units, by region or month)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "The specific data question to answer."}
            },
            "required": ["task"],
        },
    },
    {
        "name": "delegate_to_code_agent",
        "description": "Delegate a task that requires writing and running Python code to the Code Agent.",
        "input_schema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "The coding task, including any inputs/data it needs."}
            },
            "required": ["task"],
        },
    },
    {
        "name": "delegate_to_docs_agent",
        "description": "Delegate a documentation/report-writing task to the Docs Agent.",
        "input_schema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "What the document should cover, including content to include."}
            },
            "required": ["task"],
        },
    },
    {
        "name": "delegate_to_analysis_agent",
        "description": (
            "Delegate a statistics/interpretation/strategy task to the Analysis Agent. "
            "Include any concrete numbers already gathered so it doesn't have to re-derive them."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "The analysis question, including relevant numbers/context."}
            },
            "required": ["task"],
        },
    },
]

_AGENT_RUNNERS = {
    "delegate_to_data_agent": data_agent.run,
    "delegate_to_code_agent": code_agent.run,
    "delegate_to_docs_agent": docs_agent.run,
    "delegate_to_analysis_agent": analysis_agent.run,
}


def run(task: str) -> str:
    """Run the supervisor loop for a single user task and return the final synthesis."""
    messages = [{"role": "user", "content": task}]

    with timed("supervisor"):
        return _run_supervisor_loop(messages)


def _run_supervisor_loop(messages: list) -> str:
    while True:
        extra_kwargs = {}
        if config.SUPPORTS_EFFORT_AND_ADAPTIVE_THINKING:
            extra_kwargs["thinking"] = {"type": "adaptive", "display": "summarized"}
            extra_kwargs["output_config"] = {"effort": config.SUPERVISOR_EFFORT}

        response = client.messages.create(
            model=config.MODEL,
            max_tokens=config.SUPERVISOR_MAX_TOKENS,
            system=SYSTEM_PROMPT,
            tools=DELEGATION_TOOLS,
            messages=messages,
            **extra_kwargs,
        )

        if response.stop_reason == "refusal":
            return "The supervisor declined to process this request."

        for block in response.content:
            if block.type == "thinking" and block.thinking:
                log(f"(supervisor thinking) {truncate(block.thinking, 300)}")

        messages.append({"role": "assistant", "content": response.content})

        if response.stop_reason != "tool_use":
            final_text = "".join(b.text for b in response.content if b.type == "text")
            return final_text.strip()

        tool_results = []
        for block in response.content:
            if block.type != "tool_use":
                continue
            runner = _AGENT_RUNNERS.get(block.name)
            label = _AGENT_LABELS.get(block.name, block.name)

            divider("=")
            log(f"DELEGATING -> {label}")
            log(f"  task: {truncate(block.input.get('task', ''), 200)}")
            divider("=")

            if runner is None:
                result = f"Error: unknown delegation tool '{block.name}'"
                is_error = True
            else:
                try:
                    result = runner(block.input["task"])
                    is_error = False
                except Exception as exc:
                    result = f"Error running {block.name}: {exc}"
                    is_error = True

            tag = "ERROR" if is_error else "OK"
            log(f"RESULT from {label} [{tag}]: {truncate(result, 250)}")
            log("")
            tool_results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": result,
                    "is_error": is_error,
                }
            )

        messages.append({"role": "user", "content": tool_results})
