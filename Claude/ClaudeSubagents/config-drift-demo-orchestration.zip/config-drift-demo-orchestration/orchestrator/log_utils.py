"""Shared logging setup.

Every run writes a timestamped log file under logs/ (in addition to the
console) so you can review what happened after the fact instead of relying
on terminal scrollback. Import `log` from here instead of using print()
anywhere in the orchestrator/agents code.
"""

import logging
import os
import time
from datetime import datetime

_LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")

_logger = logging.getLogger("orchestration")
_log_file_path = None


def setup(run_name: str = "run") -> str:
    """Configure logging for one run. Returns the path to the log file."""
    global _log_file_path

    os.makedirs(_LOG_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    _log_file_path = os.path.join(_LOG_DIR, f"{run_name}_{timestamp}.log")

    _logger.handlers.clear()
    _logger.setLevel(logging.INFO)
    _logger.propagate = False

    formatter = logging.Formatter("%(asctime)s.%(msecs)03d  %(message)s", datefmt="%H:%M:%S")

    file_handler = logging.FileHandler(_log_file_path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    _logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    _logger.addHandler(console_handler)

    return _log_file_path


def log(message: str) -> None:
    _logger.info(message)


def log_file_path() -> str:
    return _log_file_path


def truncate(text: str, limit: int = 220) -> str:
    """Shorten long strings (e.g. generated code passed as a tool argument) for
    display, so the console/log stays scannable. The full value is always
    still available to the model — this only affects what we print."""
    text = str(text)
    if len(text) <= limit:
        return text
    return f"{text[:limit]}… [+{len(text) - limit} more chars]"


def divider(char: str = "-", width: int = 70) -> None:
    log(char * width)


class timed:
    """Context manager that logs how long a block took.

    Usage:
        with timed("data-agent"):
            ...do the work...
    Logs both the start and the elapsed time on exit, so a log file gives you
    a full timeline you can use to check whether calls overlapped (parallel)
    or ran back-to-back (sequential).
    """

    def __init__(self, label: str):
        self.label = label

    def __enter__(self):
        self.start = time.perf_counter()
        log(f"START  {self.label}")
        return self

    def __exit__(self, exc_type, exc, tb):
        elapsed = time.perf_counter() - self.start
        status = "ERROR" if exc_type else "DONE "
        log(f"{status} {self.label}  ({elapsed:.2f}s)")
        return False
