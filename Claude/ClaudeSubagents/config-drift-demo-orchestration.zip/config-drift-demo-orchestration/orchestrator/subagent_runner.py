"""Generic runner shared by every subagent.

Each subagent is just a (system prompt, tool set, tool handlers) triple. This
module drives the actual Claude API calls and the tool-use loop so the
per-agent files stay focused on *what* the agent can do, not *how* to call
the model.
"""

import json

from anthropic import AnthropicVertex

import config
from orchestrator.log_utils import log, timed, truncate

client = AnthropicVertex(project_id=config.PROJECT_ID, region=config.REGION)


def run_agent(name: str, system_prompt: str, task: str, tools=None, handlers=None) -> str:
    """Run a single subagent to completion and return its final text response.

    `tools` is a list of Anthropic tool definitions (or None). `handlers` is a
    dict mapping tool name -> callable(input_dict) -> str, used to execute
    tool calls the model makes.
    """
    tools = tools or []
    handlers = handlers or {}

    with timed(name):
        return _run_agent_loop(name, system_prompt, task, tools, handlers)


def _run_agent_loop(name: str, system_prompt: str, task: str, tools, handlers) -> str:
    # Isolation proof: this subagent's message history starts fresh, right here,
    # every single call. It contains exactly one message — the delegated task
    # string the supervisor decided to forward — and nothing from the
    # supervisor's own conversation or any other subagent's conversation.
    # That history (built up below as this agent's own tool-use loop runs) is
    # local to this function call and is discarded when run_agent() returns;
    # only the final text return value ever crosses back to the supervisor.
    messages = [{"role": "user", "content": task}]
    log(f"    | {name}: isolated context ({len(messages)} message — no supervisor/sibling history)")
    log(f"    | {name}: task = {truncate(task, 150)}")

    while True:
        extra_kwargs = {}
        if config.SUPPORTS_EFFORT_AND_ADAPTIVE_THINKING:
            extra_kwargs["output_config"] = {"effort": config.SUBAGENT_EFFORT}

        response = client.messages.create(
            model=config.MODEL,
            max_tokens=config.SUBAGENT_MAX_TOKENS,
            system=system_prompt,
            tools=tools,
            messages=messages,
            **extra_kwargs,
        )

        if response.stop_reason == "refusal":
            return f"[{name}] declined to complete this task."

        messages.append({"role": "assistant", "content": response.content})

        if response.stop_reason != "tool_use":
            text = "".join(b.text for b in response.content if b.type == "text")
            return text.strip() or f"[{name}] produced no text output."

        tool_results = []
        for block in response.content:
            if block.type != "tool_use":
                continue
            handler = handlers.get(block.name)
            log(f"    | {name}: tool call -> {block.name}({truncate(json.dumps(block.input), 150)})")
            if handler is None:
                result = f"Error: no handler registered for tool '{block.name}'"
                is_error = True
            else:
                try:
                    result = handler(block.input)
                    is_error = False
                except Exception as exc:  # tool failures are surfaced to the model, not raised
                    result = f"Error running tool '{block.name}': {exc}"
                    is_error = True
            tag = "ERROR" if is_error else "OK"
            log(f"    | {name}: tool result [{tag}] <- {truncate(result, 150)}")
            tool_results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": str(result),
                    "is_error": is_error,
                }
            )

        messages.append({"role": "user", "content": tool_results})
