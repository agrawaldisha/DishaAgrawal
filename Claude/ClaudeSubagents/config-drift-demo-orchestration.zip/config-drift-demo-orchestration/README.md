# Supervisor + Subagent Orchestration Demo

A working multi-agent system built on the Anthropic Claude API. A **supervisor**
agent analyzes an incoming task, delegates pieces of it to four **specialized
subagents**, and synthesizes their results into one final answer.

```
                     ┌───────────────┐
   user task  ─────► │  Supervisor   │
                     └───────┬───────┘
                             │ delegates via tool calls
        ┌──────────┬─────────┼─────────┬──────────┐
        ▼          ▼         ▼         ▼          
   Data Agent  Code Agent  Docs Agent  Analysis Agent
   (queries a  (writes &   (writes     (statistics +
   sample      runs Python  markdown    strategic
   sales CSV)  and verifies reports)    recommendations)
               it works)
```

Each subagent is exposed to the supervisor as a **tool** ("delegate_to_data_agent",
etc.). When the supervisor calls one, that subagent runs its own Claude call (with
its own tools) to completion, and its final answer is fed back to the supervisor as
a tool result. The supervisor then continues, delegates more work if needed, and
finally writes a synthesized answer — not just a concatenation of the four outputs.

This is the standard "agents-as-tools" pattern for hierarchical multi-agent systems,
implemented with plain `client.messages.create()` calls and manual tool-use loops
(no beta APIs, no external orchestration framework) so the whole flow is visible
and easy to modify.

## What each subagent actually does

- **Data Agent** (`agents/data_agent.py`) — queries `data/sample_sales.csv` (a small
  sales-by-region-by-month dataset) via a real aggregation tool (sum/average/max/
  min/count, optional region/month filter or group-by).
- **Code Agent** (`agents/code_agent.py`) — writes Python code and actually
  **executes it in a subprocess** to verify it works before returning it.
- **Docs Agent** (`agents/docs_agent.py`) — writes markdown reports to `output/`.
- **Analysis Agent** (`agents/analysis_agent.py`) — computes real statistics (mean,
  median, stdev, min/max) via Python's `statistics` module and produces an
  interpretation/recommendation grounded in those numbers.

None of these are "just another LLM call that pretends to have a tool" — each one
has a real Python function backing its tool(s).

## Setup

This demo talks to Claude via **Google Cloud Vertex AI**, not a raw Anthropic API
key — auth is via GCP Application Default Credentials.

```bash
pip install -r requirements.txt
gcloud auth application-default login
cp .env.example .env   # defaults are pre-filled; edit if your project/region differ
```

(`python-dotenv` is optional — if it's not installed, `export GCP_PROJECT_ID=...`
etc. in your shell instead of using a `.env` file.)

Make sure the Vertex AI API is enabled on the target project and that your
account has access to the Claude model you're requesting.

## Run it

```bash
# Preset demo task that exercises all four subagents:
python main.py --demo

# Your own task:
python main.py "What was total North region revenue in Q1, and is it trending up?"

# Interactive mode:
python main.py
```

You'll see the supervisor's delegation decisions, each subagent's tool calls, and
the final synthesized answer printed to the console. Any documents the Docs Agent
writes land in `output/`.

## Model

Defaults to `claude-haiku-4-5@20251001` on Vertex project
`learning-development-c-000027` / region `us-east5`. Override any of these via
`GCP_PROJECT_ID`, `CLAUDE_VERTEX_REGION`, `CLAUDE_MODEL` in your environment or
`.env` file.

Note: Vertex dated-snapshot model IDs use an `@` version separator
(`claude-haiku-4-5@20251001`), not a trailing hyphenated date.

The supervisor runs at `effort: high` with adaptive thinking (it's doing the
harder job of planning and synthesis); subagents run at `effort: low` — see
`config.py`. These parameters are only sent when the configured model
supports them: Haiku 4.5 and Sonnet 4.5 reject `effort`/adaptive `thinking`
outright (400 error), so `config.SUPPORTS_EFFORT_AND_ADAPTIVE_THINKING` gates
them off automatically for those models.

## Extending it

To add a fifth subagent: create `agents/your_agent.py` following the same shape
as the existing ones (a `SYSTEM_PROMPT`, a `TOOLS` list, a handler dict, and a
`run(task) -> str` function), then register a `delegate_to_your_agent` tool and
runner entry in `orchestrator/supervisor.py`.
