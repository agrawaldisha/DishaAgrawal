"""Shared configuration for the supervisor/subagent orchestration demo."""

import os
import warnings

# Load a .env file if python-dotenv is available; otherwise rely on the real
# environment. This keeps the demo dependency-light (dotenv is optional).
try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

# Cosmetic only: google-auth warns on every single API call that ADC user
# credentials have no quota project attached. It's harmless for this demo
# (billing/quota falls back to the project) and repeating it once per call
# just adds noise — silence it here so it doesn't drown out the actual
# orchestration output.
warnings.filterwarnings(
    "ignore",
    message=r".*end user credentials from Google Cloud SDK.*",
    category=UserWarning,
)

# --- Vertex AI client config ---
# Auth is via GCP Application Default Credentials, not an API key:
#   gcloud auth application-default login
PROJECT_ID = os.environ.get("GCP_PROJECT_ID", "learning-development-c-000027")
REGION = os.environ.get("CLAUDE_VERTEX_REGION", "us-east5")
MODEL = os.environ.get("CLAUDE_MODEL", "claude-haiku-4-5@20251001")

# Subagents do focused, single-purpose work — low effort keeps them fast and
# cheap. The supervisor does the harder job of planning and synthesis.
SUPERVISOR_EFFORT = "high"
SUBAGENT_EFFORT = "low"

# Haiku 4.5 (and other pre-4.6 models) reject the `effort` and adaptive-`thinking`
# parameters outright (400 error) — those params only exist on Sonnet 4.6+ /
# Opus 4.5+. Gate on model name so swapping CLAUDE_MODEL doesn't silently break.
SUPPORTS_EFFORT_AND_ADAPTIVE_THINKING = not any(
    tag in MODEL.lower() for tag in ("haiku", "sonnet-4-5", "sonnet-4.5")
)

SUPERVISOR_MAX_TOKENS = 4096
SUBAGENT_MAX_TOKENS = 2048

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
