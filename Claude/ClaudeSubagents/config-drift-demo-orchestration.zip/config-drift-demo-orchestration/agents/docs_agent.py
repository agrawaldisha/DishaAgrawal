"""Docs Agent — writes markdown documentation/reports to the output/ directory."""

import os
import re

import config
from orchestrator.subagent_runner import run_agent

NAME = "docs-agent"

SYSTEM_PROMPT = """You are the Docs Agent, a specialist in clear technical writing.

Use the `write_markdown_file` tool to save any document you produce to disk.
Write in plain, well-structured Markdown: headings, short paragraphs, and
bullet lists where useful. Confirm the filename you wrote to in your final
answer."""

TOOLS = [
    {
        "name": "write_markdown_file",
        "description": "Write a markdown document to the shared output directory.",
        "input_schema": {
            "type": "object",
            "properties": {
                "filename": {
                    "type": "string",
                    "description": "Filename to write, e.g. 'summary.md'. No path separators.",
                },
                "content": {"type": "string", "description": "Full markdown content."},
            },
            "required": ["filename", "content"],
        },
    }
]


def _handle_write_markdown_file(tool_input: dict) -> str:
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    filename = os.path.basename(tool_input["filename"])
    if not filename.endswith(".md"):
        filename += ".md"
    # Guard against a model-supplied name that resolves outside the output dir.
    filename = re.sub(r"[^\w.\-]", "_", filename)
    path = os.path.join(config.OUTPUT_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(tool_input["content"])
    return f"Wrote {len(tool_input['content'])} characters to {path}"


HANDLERS = {"write_markdown_file": _handle_write_markdown_file}


def run(task: str) -> str:
    return run_agent(NAME, SYSTEM_PROMPT, task, tools=TOOLS, handlers=HANDLERS)
