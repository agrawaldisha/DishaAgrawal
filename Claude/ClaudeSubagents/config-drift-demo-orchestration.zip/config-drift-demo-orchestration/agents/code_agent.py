"""Code Agent — writes and executes small Python snippets to solve a task.

The `execute_python` tool actually runs the code in a subprocess (with a
timeout) and returns real stdout/stderr, so this agent can verify its own
work before answering — not just generate code and hope.

Note: this runs arbitrary model-generated Python locally with no sandboxing
beyond a timeout. That's fine for this local demo where you control the
model and the machine; do not point this at untrusted input in production
without a real sandbox (container, gVisor, etc.).
"""

import os
import subprocess
import sys
import tempfile

from orchestrator.subagent_runner import run_agent

NAME = "code-agent"

SYSTEM_PROMPT = """You are the Code Agent, a specialist in writing correct, working Python code.

Use the `execute_python` tool to actually run and verify any non-trivial code
before presenting it as your final answer. If execution fails, fix the code
and try again.

Your final answer should include the complete, working code (in a fenced code
block) plus a one-line description of what it does and confirmation that you
ran it successfully."""

TOOLS = [
    {
        "name": "execute_python",
        "description": "Execute a Python code snippet and return its stdout, stderr, and exit code.",
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "The Python source code to run."},
            },
            "required": ["code"],
        },
    }
]


def _handle_execute_python(tool_input: dict) -> str:
    code = tool_input["code"]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
        f.write(code)
        path = f.name

    # Force UTF-8 for the child process's own stdout/stderr. Without this, a
    # generated script that prints a non-ASCII character (✓, →, em dash, ...)
    # crashes on Windows with UnicodeEncodeError, because the child inherits
    # the console's legacy codepage (cp1252) by default — nothing to do with
    # the code being wrong, just an environment mismatch.
    env = {**os.environ, "PYTHONIOENCODING": "utf-8"}

    try:
        result = subprocess.run(
            [sys.executable, path],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=10,
            env=env,
        )
        return (
            f"exit_code: {result.returncode}\n"
            f"stdout:\n{result.stdout}\n"
            f"stderr:\n{result.stderr}"
        )
    except subprocess.TimeoutExpired:
        return "Error: execution timed out after 10 seconds."


HANDLERS = {"execute_python": _handle_execute_python}


def run(task: str) -> str:
    return run_agent(NAME, SYSTEM_PROMPT, task, tools=TOOLS, handlers=HANDLERS)
