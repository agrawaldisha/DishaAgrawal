"""Data Agent — specializes in querying and aggregating the sample sales dataset."""

import csv

import config
from orchestrator.subagent_runner import run_agent

NAME = "data-agent"

SYSTEM_PROMPT = """You are the Data Agent, a specialist in data retrieval and aggregation.

You have access to a sales dataset (columns: month, region, revenue, units) via the
`query_sales_data` tool. Use it to answer the request precisely — call it as many
times as needed (e.g. once per region or per operation) before answering.

Respond with a concise, factual summary of the numbers you found. Do not speculate
about strategy or recommendations — that is another agent's job."""

TOOLS = [
    {
        "name": "query_sales_data",
        "description": (
            "Aggregate the sales dataset. Computes an operation over a numeric "
            "column (revenue or units), optionally filtered to one region or month, "
            "optionally grouped by region or month."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "enum": ["sum", "average", "max", "min", "count"],
                    "description": "Aggregation to perform.",
                },
                "column": {
                    "type": "string",
                    "enum": ["revenue", "units"],
                    "description": "Which numeric column to aggregate.",
                },
                "region": {
                    "type": "string",
                    "description": "Optional filter: North, South, East, or West.",
                },
                "month": {
                    "type": "string",
                    "description": "Optional filter: Jan, Feb, Mar, or Apr.",
                },
                "group_by": {
                    "type": "string",
                    "enum": ["region", "month"],
                    "description": "Optional: return one aggregate per group instead of a single number.",
                },
            },
            "required": ["operation", "column"],
        },
    }
]


def _load_rows():
    with open(f"{config.DATA_DIR}/sample_sales.csv", newline="") as f:
        return list(csv.DictReader(f))


def _aggregate(values, operation):
    if not values:
        return None
    if operation == "sum":
        return sum(values)
    if operation == "average":
        return round(sum(values) / len(values), 2)
    if operation == "max":
        return max(values)
    if operation == "min":
        return min(values)
    if operation == "count":
        return len(values)
    raise ValueError(f"Unknown operation: {operation}")


def _handle_query_sales_data(tool_input: dict) -> str:
    rows = _load_rows()
    column = tool_input["column"]
    operation = tool_input["operation"]

    if tool_input.get("region"):
        rows = [r for r in rows if r["region"].lower() == tool_input["region"].lower()]
    if tool_input.get("month"):
        rows = [r for r in rows if r["month"].lower() == tool_input["month"].lower()]

    group_by = tool_input.get("group_by")
    if group_by:
        groups = {}
        for r in rows:
            groups.setdefault(r[group_by], []).append(float(r[column]))
        return "; ".join(
            f"{key}: {_aggregate(vals, operation)}" for key, vals in groups.items()
        )

    values = [float(r[column]) for r in rows]
    return str(_aggregate(values, operation))


HANDLERS = {"query_sales_data": _handle_query_sales_data}


def run(task: str) -> str:
    return run_agent(NAME, SYSTEM_PROMPT, task, tools=TOOLS, handlers=HANDLERS)
