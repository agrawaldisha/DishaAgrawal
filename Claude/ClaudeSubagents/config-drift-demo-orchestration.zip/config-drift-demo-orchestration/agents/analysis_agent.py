"""Analysis Agent — computes statistics and gives interpretive/strategic conclusions.

This agent typically consumes numbers gathered by the Data Agent (the
supervisor passes them along in the delegated task text) and turns them into
statistics plus a recommendation.
"""

import statistics

from orchestrator.subagent_runner import run_agent

NAME = "analysis-agent"

SYSTEM_PROMPT = """You are the Analysis Agent, a specialist in quantitative analysis and
strategic interpretation.

Use the `compute_statistics` tool on any list of numbers you're given or that
you extract from the task description, rather than doing arithmetic yourself.
Then provide a short, concrete interpretation: trends, outliers, and a
one-paragraph recommendation. Be specific and reference the actual numbers."""

TOOLS = [
    {
        "name": "compute_statistics",
        "description": "Compute mean, median, min, max, and standard deviation of a list of numbers.",
        "input_schema": {
            "type": "object",
            "properties": {
                "values": {
                    "type": "array",
                    "items": {"type": "number"},
                    "description": "The numeric values to analyze.",
                },
            },
            "required": ["values"],
        },
    }
]


def _handle_compute_statistics(tool_input: dict) -> str:
    values = [float(v) for v in tool_input["values"]]
    if not values:
        return "Error: no values provided."
    result = {
        "count": len(values),
        "mean": round(statistics.mean(values), 2),
        "median": round(statistics.median(values), 2),
        "min": min(values),
        "max": max(values),
        "stdev": round(statistics.stdev(values), 2) if len(values) > 1 else 0.0,
    }
    return ", ".join(f"{k}={v}" for k, v in result.items())


HANDLERS = {"compute_statistics": _handle_compute_statistics}


def run(task: str) -> str:
    return run_agent(NAME, SYSTEM_PROMPT, task, tools=TOOLS, handlers=HANDLERS)
