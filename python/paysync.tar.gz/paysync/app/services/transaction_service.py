"""
Transaction Service
===================
All transaction business logic lives here — NOT in the router.
Routers handle HTTP; services handle business rules.

Key concepts implemented:
  1. Idempotency — same key = same result, no double charges
  2. Balance validation — can't spend more than wallet has
  3. Merchant limit enforcement — per-txn and daily volume caps
  4. KYC gate — can't transact if merchant KYC is pending
  5. Atomic ledger writes — balance + ledger entry in one DB transaction
  6. Reference ID generation — human-readable TXN IDs like TXN20240101ABCDE
"""

import json
import secrets
import string
from datetime import datetime, date
from decimal import Decimal
from uuid import UUID

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.exceptions import (
    BusinessRuleError, ConflictError, NotFoundError, IdempotencyError
)
from app.models.models import (
    Transaction, Customer, Wallet, LedgerEntry, WebhookEvent,
    TransactionStatus, TransactionType, LedgerEntryType,
    KYCStatus, MerchantStatus, Merchant,
)
from app.schemas.schemas import TransactionCreate, RefundCreate


class TransactionService:

    @staticmethod
    def create_transaction(
        db: Session,
        merchant: Merchant,
        payload: TransactionCreate,
    ) -> Transaction:
        """
        Create and process a transaction atomically.
        All balance changes and ledger entries happen in the same DB transaction.
        """

        # 1. KYC Gate — merchant must be active and KYC approved
        if merchant.kyc_status != KYCStatus.APPROVED:
            raise BusinessRuleError(
                "Merchant KYC is not approved. Cannot process transactions.",
                {"kyc_status": merchant.kyc_status.value},
            )
        if merchant.status != MerchantStatus.ACTIVE:
            raise BusinessRuleError(
                f"Merchant account is {merchant.status.value}. Cannot process transactions."
            )

        # 2. Idempotency check
        if payload.idempotency_key:
            existing = db.query(Transaction).filter(
                Transaction.idempotency_key == payload.idempotency_key,
            ).first()
            if existing:
                # Return the existing transaction — this is idempotent behaviour
                return existing

        # 3. Load customer and wallet (with row-level lock to prevent race conditions)
        customer = db.query(Customer).filter(
            Customer.id == payload.customer_id,
            Customer.merchant_id == merchant.id,
            Customer.is_deleted == False,
        ).with_for_update().first()

        if not customer:
            raise NotFoundError("Customer", str(payload.customer_id))

        if not customer.is_active:
            raise BusinessRuleError("Customer account is deactivated")

        wallet = db.query(Wallet).filter(
            Wallet.customer_id == customer.id,
        ).with_for_update().first()

        if not wallet:
            raise BusinessRuleError("Customer wallet not found")

        if wallet.is_frozen:
            raise BusinessRuleError("Customer wallet is frozen. Contact support.")

        # 4. Enforce per-transaction amount limit
        if payload.amount > merchant.max_transaction_limit:
            raise BusinessRuleError(
                f"Transaction amount {payload.amount} exceeds merchant limit of {merchant.max_transaction_limit}",
                {"limit": str(merchant.max_transaction_limit), "amount": str(payload.amount)},
            )

        # 5. Enforce daily volume limit
        today_total = TransactionService._get_daily_volume(db, merchant.id)
        if today_total + payload.amount > merchant.daily_limit:
            raise BusinessRuleError(
                "Daily transaction volume limit reached",
                {"daily_limit": str(merchant.daily_limit), "used_today": str(today_total)},
            )

        # 6. Balance check for payment and refund types
        if payload.transaction_type == TransactionType.PAYMENT:
            if wallet.balance < payload.amount:
                raise BusinessRuleError(
                    "Insufficient wallet balance",
                    {"balance": str(wallet.balance), "required": str(payload.amount)},
                )

        # 7. Create the transaction record
        txn = Transaction(
            reference_id=TransactionService._generate_reference_id(),
            merchant_id=merchant.id,
            customer_id=customer.id,
            amount=payload.amount,
            currency=payload.currency,
            transaction_type=payload.transaction_type,
            payment_method=payload.payment_method,
            status=TransactionStatus.PROCESSING,
            description=payload.description,
            idempotency_key=payload.idempotency_key,
            metadata=json.dumps(payload.metadata) if payload.metadata else None,
        )
        db.add(txn)
        db.flush()  # Get txn.id before creating ledger entries

        # 8. Apply balance change and create ledger entry (double-entry bookkeeping)
        if payload.transaction_type in (TransactionType.PAYMENT,):
            wallet.balance -= payload.amount
            entry_type = LedgerEntryType.DEBIT
        elif payload.transaction_type in (TransactionType.WALLET_TOPUP, TransactionType.REFUND):
            wallet.balance += payload.amount
            entry_type = LedgerEntryType.CREDIT
        else:
            entry_type = LedgerEntryType.DEBIT  # Settlement debits

        ledger_entry = LedgerEntry(
            wallet_id=wallet.id,
            transaction_id=txn.id,
            entry_type=entry_type,
            amount=payload.amount,
            balance_after=wallet.balance,
            description=payload.description or f"{payload.transaction_type.value} — {txn.reference_id}",
        )
        db.add(ledger_entry)

        # 9. Mark transaction as successful (in a real system, this happens after payment provider confirms)
        txn.status = TransactionStatus.SUCCESS

        # 10. Queue webhook to notify merchant (don't await — fire and forget)
        TransactionService._create_webhook_event(db, txn)

        db.commit()
        db.refresh(txn)
        return txn

    @staticmethod
    def create_refund(
        db: Session,
        merchant: Merchant,
        transaction_id: UUID,
        payload: RefundCreate,
    ) -> Transaction:
        """
        Refund a successful transaction — partial or full.
        Creates a new REFUND transaction linked to the original.
        """
        original = db.query(Transaction).filter(
            Transaction.id == transaction_id,
            Transaction.merchant_id == merchant.id,
        ).first()

        if not original:
            raise NotFoundError("Transaction", str(transaction_id))

        if original.status != TransactionStatus.SUCCESS:
            raise BusinessRuleError(
                f"Only successful transactions can be refunded. Current status: {original.status.value}"
            )

        # Calculate already-refunded amount
        already_refunded = db.query(
            func.coalesce(func.sum(Transaction.amount), 0)
        ).filter(
            Transaction.parent_transaction_id == original.id,
            Transaction.transaction_type == TransactionType.REFUND,
            Transaction.status == TransactionStatus.SUCCESS,
        ).scalar()

        refundable = original.amount - already_refunded
        if payload.amount > refundable:
            raise BusinessRuleError(
                f"Refund amount {payload.amount} exceeds refundable amount {refundable}",
                {"refundable": str(refundable), "requested": str(payload.amount)},
            )

        # Load customer wallet
        customer = db.query(Customer).filter(Customer.id == original.customer_id).first()
        wallet = db.query(Wallet).filter(
            Wallet.customer_id == customer.id
        ).with_for_update().first()

        # Create refund transaction
        refund_txn = Transaction(
            reference_id=TransactionService._generate_reference_id(prefix="RFD"),
            merchant_id=merchant.id,
            customer_id=original.customer_id,
            amount=payload.amount,
            currency=original.currency,
            transaction_type=TransactionType.REFUND,
            payment_method=original.payment_method,
            status=TransactionStatus.PROCESSING,
            description=payload.reason or f"Refund for {original.reference_id}",
            idempotency_key=payload.idempotency_key,
            parent_transaction_id=original.id,
        )
        db.add(refund_txn)
        db.flush()

        # Credit wallet
        wallet.balance += payload.amount
        ledger_entry = LedgerEntry(
            wallet_id=wallet.id,
            transaction_id=refund_txn.id,
            entry_type=LedgerEntryType.CREDIT,
            amount=payload.amount,
            balance_after=wallet.balance,
            description=refund_txn.description,
        )
        db.add(ledger_entry)

        refund_txn.status = TransactionStatus.SUCCESS

        # Update parent status
        if payload.amount == refundable:
            original.status = TransactionStatus.REFUNDED
        else:
            original.status = TransactionStatus.PARTIALLY_REFUNDED

        TransactionService._create_webhook_event(db, refund_txn)
        db.commit()
        db.refresh(refund_txn)
        return refund_txn

    @staticmethod
    def _get_daily_volume(db: Session, merchant_id: UUID) -> Decimal:
        """Sum of all successful transactions today for this merchant."""
        today_start = datetime.combine(date.today(), datetime.min.time())
        result = db.query(
            func.coalesce(func.sum(Transaction.amount), Decimal("0"))
        ).filter(
            Transaction.merchant_id == merchant_id,
            Transaction.status == TransactionStatus.SUCCESS,
            Transaction.transaction_type == TransactionType.PAYMENT,
            Transaction.created_at >= today_start,
        ).scalar()
        return Decimal(str(result))

    @staticmethod
    def _generate_reference_id(prefix: str = "TXN") -> str:
        """Generate human-readable reference like TXN20240101XKZP."""
        date_part = datetime.utcnow().strftime("%Y%m%d")
        random_part = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
        return f"{prefix}{date_part}{random_part}"

    @staticmethod
    def _create_webhook_event(db: Session, txn: Transaction) -> None:
        """Create a webhook event record. Actual delivery happens in background worker."""
        import json
        payload = {
            "event": f"transaction.{txn.status.value}",
            "transaction": {
                "id": str(txn.id),
                "reference_id": txn.reference_id,
                "amount": str(txn.amount),
                "currency": txn.currency,
                "type": txn.transaction_type.value,
                "status": txn.status.value,
            },
            "timestamp": datetime.utcnow().isoformat(),
        }
        event = WebhookEvent(
            merchant_id=txn.merchant_id,
            transaction_id=txn.id,
            event_type=f"transaction.{txn.status.value}",
            payload=json.dumps(payload),
        )
        db.add(event)
