"""
Webhook Service
===============
Responsible for delivering webhook events to merchant callback URLs.

Flow:
  1. TransactionService creates WebhookEvent records (status=pending)
  2. After transaction API returns, BackgroundTask calls dispatch_pending_webhooks
  3. We POST the payload to merchant's webhook_url with HMAC-SHA256 signature
  4. On failure, we schedule retries with exponential backoff
  5. After max retries, status becomes 'failed' — merchant can trigger manual retry

HMAC signature format (same as Stripe's):
  X-PaySync-Signature: t=<timestamp>,v1=<hmac_hex>
"""

import hashlib
import hmac
import json
import time
from datetime import datetime, timedelta

import httpx
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import SessionLocal
from app.models.models import WebhookEvent, WebhookStatus, Merchant


class WebhookService:

    @staticmethod
    def dispatch_pending_webhooks(merchant: Merchant) -> None:
        """
        Called as a BackgroundTask after transaction creation.
        Opens its own DB session since background tasks run after the request context closes.
        """
        db = SessionLocal()
        try:
            pending = db.query(WebhookEvent).filter(
                WebhookEvent.merchant_id == merchant.id,
                WebhookEvent.status.in_([WebhookStatus.PENDING, WebhookStatus.RETRYING]),
            ).all()

            for event in pending:
                WebhookService._deliver(db, event, merchant.webhook_url)

        finally:
            db.close()

    @staticmethod
    def _deliver(db: Session, event: WebhookEvent, webhook_url: str) -> None:
        if not webhook_url:
            event.status = WebhookStatus.FAILED
            event.failure_reason = "No webhook URL configured"
            db.commit()
            return

        timestamp = str(int(time.time()))
        signature = WebhookService._sign_payload(event.payload, timestamp)

        headers = {
            "Content-Type": "application/json",
            "X-PaySync-Signature": f"t={timestamp},v1={signature}",
            "X-PaySync-Event": event.event_type,
            "X-PaySync-Delivery": str(event.id),
        }

        event.attempt_count += 1
        event.last_attempted_at = datetime.utcnow()

        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.post(
                    webhook_url,
                    content=event.payload,
                    headers=headers,
                )
            event.response_code = response.status_code
            event.response_body = response.text[:1000]  # Truncate large responses

            if response.status_code in range(200, 300):
                event.status = WebhookStatus.DELIVERED
            else:
                WebhookService._schedule_retry(event)

        except Exception as exc:
            event.response_code = None
            event.response_body = str(exc)[:500]
            WebhookService._schedule_retry(event)

        db.commit()

    @staticmethod
    def _schedule_retry(event: WebhookEvent) -> None:
        """Exponential backoff: 1min, 5min, 30min, then fail."""
        backoff_minutes = [1, 5, 30]
        if event.attempt_count >= settings.WEBHOOK_RETRY_ATTEMPTS:
            event.status = WebhookStatus.FAILED
        else:
            event.status = WebhookStatus.RETRYING
            delay = backoff_minutes[min(event.attempt_count - 1, len(backoff_minutes) - 1)]
            event.next_retry_at = datetime.utcnow() + timedelta(minutes=delay)

    @staticmethod
    def _sign_payload(payload: str, timestamp: str) -> str:
        """
        HMAC-SHA256 signature for webhook authenticity verification.
        Merchant verifies: hmac(secret, f"{timestamp}.{payload}") == v1 value
        """
        message = f"{timestamp}.{payload}".encode()
        return hmac.new(
            settings.WEBHOOK_SECRET.encode(),
            message,
            hashlib.sha256,
        ).hexdigest()

    @staticmethod
    def verify_signature(payload: str, header: str) -> bool:
        """
        Helper for merchants to verify incoming webhook signatures.
        Usage in your FastAPI webhook receiver:
            if not WebhookService.verify_signature(raw_body, request.headers.get("X-PaySync-Signature")):
                raise HTTPException(403)
        """
        try:
            parts = dict(p.split("=", 1) for p in header.split(","))
            timestamp = parts["t"]
            received_sig = parts["v1"]
            expected_sig = WebhookService._sign_payload(payload, timestamp)

            # Constant-time comparison to prevent timing attacks
            return hmac.compare_digest(received_sig, expected_sig)
        except Exception:
            return False
