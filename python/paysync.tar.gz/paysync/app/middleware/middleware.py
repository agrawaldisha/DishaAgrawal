"""
Middleware
==========
1. RequestIDMiddleware  — attaches a unique X-Request-ID to every request/response
2. AuditLogMiddleware   — logs all mutating requests (POST/PUT/PATCH/DELETE) to audit_logs table
"""

import json
import time
import uuid
from typing import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from app.core.database import SessionLocal
from app.models.models import AuditLog


class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        request.state.start_time = time.time()

        response = await call_next(request)

        duration_ms = round((time.time() - request.state.start_time) * 1000, 2)
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Response-Time"] = f"{duration_ms}ms"
        return response


class AuditLogMiddleware(BaseHTTPMiddleware):
    SKIP_PATHS = {"/health", "/docs", "/openapi.json", "/redoc", "/favicon.ico"}
    MUTATING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        if (
            request.url.path in self.SKIP_PATHS
            or request.method not in self.MUTATING_METHODS
        ):
            return await call_next(request)

        response = await call_next(request)

        # Log asynchronously — do not block the response
        try:
            actor_id = None
            actor_type = "anonymous"
            merchant_id = None

            # Try to extract actor from request state (set by auth dependencies)
            if hasattr(request.state, "current_user") and request.state.current_user:
                actor_id = str(request.state.current_user.id)
                actor_type = "user"
                if request.state.current_user.merchant_id:
                    merchant_id = str(request.state.current_user.merchant_id)

            elif hasattr(request.state, "merchant") and request.state.merchant:
                actor_id = str(request.state.merchant.id)
                actor_type = "merchant_api"
                merchant_id = str(request.state.merchant.id)

            db = SessionLocal()
            try:
                log = AuditLog(
                    actor_id=actor_id,
                    actor_type=actor_type,
                    merchant_id=merchant_id,
                    action=f"{request.method} {request.url.path}",
                    resource_type=self._infer_resource(request.url.path),
                    ip_address=request.client.host if request.client else None,
                    user_agent=request.headers.get("user-agent"),
                    success=response.status_code < 400,
                    failure_reason=None if response.status_code < 400 else f"HTTP {response.status_code}",
                )
                db.add(log)
                db.commit()
            finally:
                db.close()

        except Exception:
            pass  # Never let audit logging break the request

        return response

    def _infer_resource(self, path: str) -> str:
        parts = path.strip("/").split("/")
        # /api/v1/transactions/xxx -> "Transaction"
        for part in ["transactions", "merchants", "customers", "settlements", "webhooks", "users"]:
            if part in parts:
                return part.rstrip("s").capitalize()
        return "Unknown"
