from typing import List, Optional
from uuid import UUID
from datetime import datetime

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import require_super_admin
from app.models.models import AuditLog, User, Merchant, Transaction, TransactionStatus
from app.schemas.schemas import UserResponse

router = APIRouter(prefix="/admin", tags=["Admin"])


@router.get("/stats", response_model=dict)
def platform_stats(
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),
):
    """Platform-wide statistics for the PaySync ops dashboard."""
    from sqlalchemy import func
    from decimal import Decimal

    total_merchants = db.query(func.count(Merchant.id)).filter(Merchant.is_deleted == False).scalar()
    total_transactions = db.query(func.count(Transaction.id)).scalar()
    total_volume = db.query(
        func.coalesce(func.sum(Transaction.amount), 0)
    ).filter(Transaction.status == TransactionStatus.SUCCESS).scalar()

    return {
        "total_merchants": total_merchants,
        "total_transactions": total_transactions,
        "total_volume_inr": str(total_volume),
    }


@router.get("/audit-logs", response_model=List[dict])
def list_audit_logs(
    actor_id: Optional[UUID] = Query(None),
    merchant_id: Optional[UUID] = Query(None),
    action: Optional[str] = Query(None),
    from_date: Optional[datetime] = Query(None),
    to_date: Optional[datetime] = Query(None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),
):
    """Query audit logs. Super admin only. Used for compliance and fraud investigation."""
    q = db.query(AuditLog)
    if actor_id:
        q = q.filter(AuditLog.actor_id == str(actor_id))
    if merchant_id:
        q = q.filter(AuditLog.merchant_id == str(merchant_id))
    if action:
        q = q.filter(AuditLog.action.ilike(f"%{action}%"))
    if from_date:
        q = q.filter(AuditLog.created_at >= from_date)
    if to_date:
        q = q.filter(AuditLog.created_at <= to_date)

    logs = q.order_by(AuditLog.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()

    return [
        {
            "id": str(log.id),
            "actor_id": str(log.actor_id) if log.actor_id else None,
            "actor_type": log.actor_type,
            "merchant_id": str(log.merchant_id) if log.merchant_id else None,
            "action": log.action,
            "resource_type": log.resource_type,
            "resource_id": log.resource_id,
            "ip_address": log.ip_address,
            "success": log.success,
            "failure_reason": log.failure_reason,
            "created_at": log.created_at.isoformat(),
        }
        for log in logs
    ]


@router.get("/users", response_model=List[UserResponse])
def list_users(
    merchant_id: Optional[UUID] = Query(None),
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),
):
    """List all platform users. Optionally filter by merchant."""
    q = db.query(User).filter(User.is_deleted == False)
    if merchant_id:
        q = q.filter(User.merchant_id == merchant_id)
    return q.order_by(User.created_at.desc()).all()
