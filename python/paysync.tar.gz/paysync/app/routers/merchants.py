from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import require_super_admin, require_merchant_admin, get_current_active_user
from app.core.exceptions import NotFoundError, ConflictError, ForbiddenError
from app.core.security import generate_api_key
from app.models.models import Merchant, MerchantAPIKey, User, MerchantStatus, UserRole
from app.schemas.schemas import (
    MerchantCreate, MerchantUpdate, MerchantResponse,
    MerchantAPIKeyCreate, MerchantAPIKeyResponse,
)

router = APIRouter(prefix="/merchants", tags=["Merchants"])


# ─── Merchant CRUD ────────────────────────────────────────────────────────────

@router.post("", response_model=MerchantResponse, status_code=201)
def create_merchant(
    payload: MerchantCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),     # Only super admin can onboard merchants
):
    """
    Onboard a new merchant onto the PaySync platform.
    Initial status is PENDING_KYC — they cannot process transactions until KYC is approved.
    """
    existing = db.query(Merchant).filter(Merchant.email == payload.email).first()
    if existing:
        raise ConflictError(f"Merchant with email {payload.email} already registered")

    merchant = Merchant(**payload.model_dump())
    db.add(merchant)
    db.commit()
    db.refresh(merchant)
    return merchant


@router.get("", response_model=List[MerchantResponse])
def list_merchants(
    status: MerchantStatus = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),
):
    """List all merchants. Super admin only. Supports filtering by status."""
    q = db.query(Merchant).filter(Merchant.is_deleted == False)
    if status:
        q = q.filter(Merchant.status == status)
    return q.order_by(Merchant.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()


@router.get("/{merchant_id}", response_model=MerchantResponse)
def get_merchant(
    merchant_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """
    Get merchant details.
    Super admins can view any merchant.
    Merchant users can only view their own merchant.
    """
    merchant = _get_merchant_or_404(merchant_id, db)

    if current_user.role != UserRole.SUPER_ADMIN:
        if current_user.merchant_id != merchant_id:
            raise ForbiddenError("You can only access your own merchant account")

    return merchant


@router.patch("/{merchant_id}", response_model=MerchantResponse)
def update_merchant(
    merchant_id: UUID,
    payload: MerchantUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_merchant_admin),
):
    """Update merchant profile. Merchant admins can update their own; super admin can update any."""
    merchant = _get_merchant_or_404(merchant_id, db)

    if current_user.role != UserRole.SUPER_ADMIN:
        if current_user.merchant_id != merchant_id:
            raise ForbiddenError("You can only update your own merchant account")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(merchant, field, value)

    db.commit()
    db.refresh(merchant)
    return merchant


@router.patch("/{merchant_id}/status", response_model=MerchantResponse)
def update_merchant_status(
    merchant_id: UUID,
    status: MerchantStatus,
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),
):
    """Activate, suspend, or close a merchant. Super admin only."""
    merchant = _get_merchant_or_404(merchant_id, db)
    merchant.status = status
    db.commit()
    db.refresh(merchant)
    return merchant


@router.patch("/{merchant_id}/kyc", response_model=MerchantResponse)
def update_kyc_status(
    merchant_id: UUID,
    kyc_status: str,
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),
):
    """Update KYC verification status. Auto-activates merchant when KYC is approved."""
    from app.models.models import KYCStatus
    merchant = _get_merchant_or_404(merchant_id, db)
    merchant.kyc_status = KYCStatus(kyc_status)

    # Auto-activate merchant when KYC is approved
    if merchant.kyc_status == KYCStatus.APPROVED:
        merchant.status = MerchantStatus.ACTIVE

    db.commit()
    db.refresh(merchant)
    return merchant


@router.delete("/{merchant_id}", status_code=204)
def delete_merchant(
    merchant_id: UUID,
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),
):
    """Soft-delete a merchant. Data is never removed for compliance."""
    from datetime import datetime
    merchant = _get_merchant_or_404(merchant_id, db)
    merchant.is_deleted = True
    merchant.deleted_at = datetime.utcnow()
    merchant.status = MerchantStatus.CLOSED
    db.commit()


# ─── API Key Management ───────────────────────────────────────────────────────

@router.post("/{merchant_id}/api-keys", response_model=MerchantAPIKeyResponse, status_code=201)
def create_api_key(
    merchant_id: UUID,
    payload: MerchantAPIKeyCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_merchant_admin),
):
    """
    Generate a new API key for a merchant.
    The raw key is returned ONCE and never stored — only the SHA-256 hash is saved.
    Treat the raw key like a password.
    """
    _get_merchant_or_404(merchant_id, db)

    if current_user.role != UserRole.SUPER_ADMIN and current_user.merchant_id != merchant_id:
        raise ForbiddenError("Access denied")

    raw_key, key_hash = generate_api_key()

    api_key = MerchantAPIKey(
        merchant_id=merchant_id,
        key_hash=key_hash,
        key_prefix=raw_key[:12],    # Store first 12 chars so merchant can identify the key
        name=payload.name,
    )
    db.add(api_key)
    db.commit()
    db.refresh(api_key)

    # Attach raw key to response — only time it will ever be visible
    response = MerchantAPIKeyResponse.model_validate(api_key)
    response.raw_key = raw_key
    return response


@router.get("/{merchant_id}/api-keys", response_model=List[MerchantAPIKeyResponse])
def list_api_keys(
    merchant_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_merchant_admin),
):
    """List all API keys for a merchant. Raw keys are never returned after creation."""
    _get_merchant_or_404(merchant_id, db)

    if current_user.role != UserRole.SUPER_ADMIN and current_user.merchant_id != merchant_id:
        raise ForbiddenError("Access denied")

    return db.query(MerchantAPIKey).filter(
        MerchantAPIKey.merchant_id == merchant_id,
    ).order_by(MerchantAPIKey.created_at.desc()).all()


@router.delete("/{merchant_id}/api-keys/{key_id}", status_code=204)
def revoke_api_key(
    merchant_id: UUID,
    key_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_merchant_admin),
):
    """Revoke (deactivate) an API key immediately."""
    api_key = db.query(MerchantAPIKey).filter(
        MerchantAPIKey.id == key_id,
        MerchantAPIKey.merchant_id == merchant_id,
    ).first()

    if not api_key:
        raise NotFoundError("API key")

    if current_user.role != UserRole.SUPER_ADMIN and current_user.merchant_id != merchant_id:
        raise ForbiddenError("Access denied")

    api_key.is_active = False
    db.commit()


# ─── Internal helpers ─────────────────────────────────────────────────────────

def _get_merchant_or_404(merchant_id: UUID, db: Session) -> Merchant:
    merchant = db.query(Merchant).filter(
        Merchant.id == merchant_id,
        Merchant.is_deleted == False,
    ).first()
    if not merchant:
        raise NotFoundError("Merchant", str(merchant_id))
    return merchant
