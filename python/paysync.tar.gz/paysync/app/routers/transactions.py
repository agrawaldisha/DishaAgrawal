from typing import List, Optional
from uuid import UUID
from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, Query, BackgroundTasks
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_merchant_from_api_key, require_super_admin, get_current_active_user
from app.core.exceptions import NotFoundError
from app.models.models import (
    Merchant, Transaction, LedgerEntry, WebhookEvent,
    TransactionStatus, TransactionType, PaymentMethod, User, UserRole,
)
from app.schemas.schemas import (
    TransactionCreate, TransactionResponse, RefundCreate,
    LedgerEntryResponse, WebhookEventResponse,
)
from app.services.transaction_service import TransactionService
from app.services.webhook_service import WebhookService

router = APIRouter(prefix="/transactions", tags=["Transactions"])


@router.post("", response_model=TransactionResponse, status_code=201)
def create_transaction(
    payload: TransactionCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """
    Create and process a transaction.

    Idempotency: Pass `idempotency_key` in the request body to safely retry.
    If the same key is sent twice, the original transaction is returned — no double charge.

    Webhook: The merchant's `webhook_url` will receive a POST after the transaction completes.
    """
    txn = TransactionService.create_transaction(db, merchant, payload)

    # Fire webhooks in background — doesn't block the API response
    background_tasks.add_task(WebhookService.dispatch_pending_webhooks, merchant)

    return txn


@router.get("", response_model=List[TransactionResponse])
def list_transactions(
    # Filters
    status: Optional[TransactionStatus] = Query(None),
    transaction_type: Optional[TransactionType] = Query(None),
    payment_method: Optional[PaymentMethod] = Query(None),
    customer_id: Optional[UUID] = Query(None),
    min_amount: Optional[Decimal] = Query(None, ge=0),
    max_amount: Optional[Decimal] = Query(None),
    from_date: Optional[datetime] = Query(None),
    to_date: Optional[datetime] = Query(None),
    reference_id: Optional[str] = Query(None),
    # Pagination
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    # Sort
    sort_by: str = Query(default="created_at", pattern="^(created_at|amount|status)$"),
    sort_order: str = Query(default="desc", pattern="^(asc|desc)$"),
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """
    List transactions for the authenticated merchant with rich filtering.

    Examples:
    - `?status=success&from_date=2024-01-01` — all successful txns this year
    - `?customer_id=xxx&min_amount=1000` — high-value txns for a customer
    - `?payment_method=upi&page=2` — paginated UPI transactions
    """
    q = db.query(Transaction).filter(Transaction.merchant_id == merchant.id)

    if status:
        q = q.filter(Transaction.status == status)
    if transaction_type:
        q = q.filter(Transaction.transaction_type == transaction_type)
    if payment_method:
        q = q.filter(Transaction.payment_method == payment_method)
    if customer_id:
        q = q.filter(Transaction.customer_id == customer_id)
    if min_amount is not None:
        q = q.filter(Transaction.amount >= min_amount)
    if max_amount is not None:
        q = q.filter(Transaction.amount <= max_amount)
    if from_date:
        q = q.filter(Transaction.created_at >= from_date)
    if to_date:
        q = q.filter(Transaction.created_at <= to_date)
    if reference_id:
        q = q.filter(Transaction.reference_id.ilike(f"%{reference_id}%"))

    # Dynamic sort
    sort_col = getattr(Transaction, sort_by)
    if sort_order == "desc":
        q = q.order_by(sort_col.desc())
    else:
        q = q.order_by(sort_col.asc())

    return q.offset((page - 1) * page_size).limit(page_size).all()


@router.get("/summary", response_model=dict)
def transaction_summary(
    from_date: Optional[datetime] = Query(None),
    to_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """
    Aggregate stats for the merchant dashboard.
    Returns total volume, count, success rate, and breakdown by status.
    """
    from sqlalchemy import func, case
    from decimal import Decimal

    q = db.query(Transaction).filter(Transaction.merchant_id == merchant.id)
    if from_date:
        q = q.filter(Transaction.created_at >= from_date)
    if to_date:
        q = q.filter(Transaction.created_at <= to_date)

    all_txns = q.all()
    total = len(all_txns)
    if total == 0:
        return {"total_count": 0, "total_volume": "0.00", "success_rate": "0.00", "by_status": {}}

    total_volume = sum(t.amount for t in all_txns if t.status == TransactionStatus.SUCCESS)
    successful = sum(1 for t in all_txns if t.status == TransactionStatus.SUCCESS)
    by_status = {}
    for txn in all_txns:
        by_status[txn.status.value] = by_status.get(txn.status.value, 0) + 1

    return {
        "total_count": total,
        "total_volume": str(total_volume),
        "success_rate": f"{(successful / total * 100):.2f}",
        "by_status": by_status,
    }


@router.get("/{transaction_id}", response_model=TransactionResponse)
def get_transaction(
    transaction_id: UUID,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    return _get_txn_or_404(transaction_id, merchant.id, db)


@router.post("/{transaction_id}/refund", response_model=TransactionResponse, status_code=201)
def refund_transaction(
    transaction_id: UUID,
    payload: RefundCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """
    Issue a full or partial refund on a successful transaction.
    Creates a new REFUND transaction and credits the customer's wallet.
    """
    refund = TransactionService.create_refund(db, merchant, transaction_id, payload)
    background_tasks.add_task(WebhookService.dispatch_pending_webhooks, merchant)
    return refund


@router.get("/{transaction_id}/ledger", response_model=List[LedgerEntryResponse])
def get_transaction_ledger(
    transaction_id: UUID,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """Get the immutable ledger entries for a transaction. The source of truth for balance changes."""
    _get_txn_or_404(transaction_id, merchant.id, db)
    return db.query(LedgerEntry).filter(
        LedgerEntry.transaction_id == transaction_id
    ).order_by(LedgerEntry.created_at.asc()).all()


@router.get("/{transaction_id}/webhooks", response_model=List[WebhookEventResponse])
def get_transaction_webhooks(
    transaction_id: UUID,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """Get webhook delivery history for a transaction."""
    _get_txn_or_404(transaction_id, merchant.id, db)
    return db.query(WebhookEvent).filter(
        WebhookEvent.transaction_id == transaction_id
    ).order_by(WebhookEvent.created_at.desc()).all()


def _get_txn_or_404(transaction_id: UUID, merchant_id, db: Session) -> Transaction:
    txn = db.query(Transaction).filter(
        Transaction.id == transaction_id,
        Transaction.merchant_id == merchant_id,
    ).first()
    if not txn:
        raise NotFoundError("Transaction", str(transaction_id))
    return txn
