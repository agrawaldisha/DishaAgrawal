from datetime import datetime

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.exceptions import UnauthorizedError, NotFoundError
from app.core.security import (
    verify_password, hash_password,
    create_access_token, create_refresh_token, decode_token
)
from app.core.config import settings
from app.models.models import User
from app.schemas.schemas import LoginRequest, TokenResponse, RefreshRequest, UserCreate, UserResponse

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    """
    Authenticate with email + password.
    Returns JWT access token (short-lived) and refresh token (long-lived).
    """
    user = db.query(User).filter(
        User.email == payload.email,
        User.is_deleted == False,
    ).first()

    if not user or not verify_password(payload.password, user.hashed_password):
        raise UnauthorizedError("Invalid email or password")

    if not user.is_active:
        raise UnauthorizedError("Account is deactivated. Contact support.")

    # Update last login
    user.last_login_at = datetime.utcnow()
    db.commit()

    token_data = {
        "sub": str(user.id),
        "email": user.email,
        "role": user.role.value,
        "merchant_id": str(user.merchant_id) if user.merchant_id else None,
    }

    return TokenResponse(
        access_token=create_access_token(token_data),
        refresh_token=create_refresh_token(token_data),
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/refresh", response_model=TokenResponse)
def refresh_token(payload: RefreshRequest, db: Session = Depends(get_db)):
    """
    Exchange a valid refresh token for a new access token.
    Used by frontend to silently re-authenticate before expiry.
    """
    from jose import JWTError
    try:
        token_data = decode_token(payload.refresh_token)
        if token_data.get("type") != "refresh":
            raise UnauthorizedError("Not a refresh token")
    except JWTError:
        raise UnauthorizedError("Refresh token is invalid or expired")

    user = db.query(User).filter(
        User.id == token_data["sub"],
        User.is_deleted == False,
        User.is_active == True,
    ).first()

    if not user:
        raise UnauthorizedError("User not found")

    new_token_data = {
        "sub": str(user.id),
        "email": user.email,
        "role": user.role.value,
        "merchant_id": str(user.merchant_id) if user.merchant_id else None,
    }

    return TokenResponse(
        access_token=create_access_token(new_token_data),
        refresh_token=create_refresh_token(new_token_data),
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/register", response_model=UserResponse, status_code=201)
def register_super_admin(payload: UserCreate, db: Session = Depends(get_db)):
    """
    Bootstrap endpoint — creates the first super admin.
    In production, disable after first use or guard with an env secret.
    """
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        from app.core.exceptions import ConflictError
        raise ConflictError(f"User with email {payload.email} already exists")

    user = User(
        email=payload.email,
        hashed_password=hash_password(payload.password),
        full_name=payload.full_name,
        role=payload.role,
        merchant_id=payload.merchant_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user
