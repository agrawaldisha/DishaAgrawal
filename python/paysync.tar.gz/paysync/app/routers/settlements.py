"""
Settlements Router
==================
Settlements = daily batch payouts from PaySync to merchant's bank account.

Flow:
  1. At end of day, admin triggers settlement for a merchant
  2. All SUCCESS transactions since last settlement are included
  3. PaySync fee (2% default) and GST (18% on fee) are deducted
  4. Net amount is transferred to merchant's bank via NEFT
  5. UTR number is recorded once bank confirms transfer
"""

from datetime import datetime, timedelta
from decimal import Decimal
from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import require_super_admin, get_merchant_from_api_key
from app.core.exceptions import BusinessRuleError, NotFoundError
from app.models.models import (
    Settlement, SettlementStatus, Transaction, TransactionStatus,
    TransactionType, Merchant, User,
)
from app.schemas.schemas import SettlementResponse

router = APIRouter(prefix="/settlements", tags=["Settlements"])

PAYYSNC_FEE_RATE = Decimal("0.02")   # 2% platform fee
GST_RATE = Decimal("0.18")           # 18% GST on the fee


@router.post("/trigger/{merchant_id}", response_model=SettlementResponse, status_code=201)
def trigger_settlement(
    merchant_id: UUID,
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),
):
    """
    Trigger end-of-day settlement for a merchant.
    Calculates net payable after fee deduction and creates the settlement record.
    In production, a Celery cron job calls this automatically at midnight.
    """
    # Get all unsettled successful payment transactions for this merchant
    last_settlement = db.query(Settlement).filter(
        Settlement.merchant_id == merchant_id,
        Settlement.status == SettlementStatus.COMPLETED,
    ).order_by(Settlement.settlement_date.desc()).first()

    from_date = last_settlement.settlement_date if last_settlement else datetime(2000, 1, 1)

    unsettled_txns = db.query(Transaction).filter(
        Transaction.merchant_id == merchant_id,
        Transaction.status == TransactionStatus.SUCCESS,
        Transaction.transaction_type == TransactionType.PAYMENT,
        Transaction.created_at > from_date,
    ).all()

    if not unsettled_txns:
        raise BusinessRuleError("No unsettled transactions found for this merchant")

    gross = sum(t.amount for t in unsettled_txns)
    fee = (gross * PAYYSNC_FEE_RATE).quantize(Decimal("0.01"))
    tax = (fee * GST_RATE).quantize(Decimal("0.01"))
    net = gross - fee - tax

    settlement = Settlement(
        merchant_id=merchant_id,
        settlement_date=datetime.utcnow(),
        gross_amount=gross,
        fee_amount=fee,
        tax_amount=tax,
        net_amount=net,
        transaction_count=len(unsettled_txns),
        status=SettlementStatus.PROCESSING,
    )
    db.add(settlement)
    db.commit()
    db.refresh(settlement)
    return settlement


@router.patch("/{settlement_id}/complete", response_model=SettlementResponse)
def mark_settlement_complete(
    settlement_id: UUID,
    utr_number: str = Query(..., description="UTR number from bank transfer confirmation"),
    db: Session = Depends(get_db),
    _: User = Depends(require_super_admin),
):
    """Mark a settlement as completed once bank transfer is confirmed."""
    settlement = db.query(Settlement).filter(Settlement.id == settlement_id).first()
    if not settlement:
        raise NotFoundError("Settlement", str(settlement_id))

    settlement.status = SettlementStatus.COMPLETED
    settlement.utr_number = utr_number
    db.commit()
    db.refresh(settlement)
    return settlement


@router.get("", response_model=List[SettlementResponse])
def list_settlements(
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """List all settlements for the authenticated merchant."""
    return db.query(Settlement).filter(
        Settlement.merchant_id == merchant.id,
    ).order_by(Settlement.settlement_date.desc()).offset((page - 1) * page_size).limit(page_size).all()


@router.get("/{settlement_id}", response_model=SettlementResponse)
def get_settlement(
    settlement_id: UUID,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    settlement = db.query(Settlement).filter(
        Settlement.id == settlement_id,
        Settlement.merchant_id == merchant.id,
    ).first()
    if not settlement:
        raise NotFoundError("Settlement", str(settlement_id))
    return settlement
