from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import get_merchant_from_api_key
from app.core.exceptions import NotFoundError, ConflictError, BusinessRuleError
from app.models.models import Customer, Merchant, Wallet, CustomerPaymentMethod
from app.schemas.schemas import (
    CustomerCreate, CustomerUpdate, CustomerResponse,
    PaymentMethodCreate, PaymentMethodResponse, WalletTopupRequest,
)

router = APIRouter(prefix="/customers", tags=["Customers"])


@router.post("", response_model=CustomerResponse, status_code=201)
def create_customer(
    payload: CustomerCreate,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """
    Register a customer under the authenticated merchant.
    Customers are merchant-scoped — same email can exist across different merchants.
    A wallet is auto-created with zero balance.
    """
    existing = db.query(Customer).filter(
        Customer.merchant_id == merchant.id,
        Customer.email == payload.email,
        Customer.is_deleted == False,
    ).first()
    if existing:
        raise ConflictError(f"Customer with email {payload.email} already exists for this merchant")

    customer = Customer(
        merchant_id=merchant.id,
        **payload.model_dump(),
    )
    db.add(customer)
    db.flush()  # Get customer.id before creating wallet

    wallet = Wallet(customer_id=customer.id, balance=0.00, currency="INR")
    db.add(wallet)
    db.commit()
    db.refresh(customer)
    return customer


@router.get("", response_model=List[CustomerResponse])
def list_customers(
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    search: str = Query(default=None, description="Search by name, email, or phone"),
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """List all customers for the authenticated merchant."""
    q = db.query(Customer).filter(
        Customer.merchant_id == merchant.id,
        Customer.is_deleted == False,
    )
    if search:
        q = q.filter(
            (Customer.email.ilike(f"%{search}%")) |
            (Customer.full_name.ilike(f"%{search}%")) |
            (Customer.phone.ilike(f"%{search}%"))
        )
    return q.order_by(Customer.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()


@router.get("/{customer_id}", response_model=CustomerResponse)
def get_customer(
    customer_id: UUID,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    return _get_customer_or_404(customer_id, merchant.id, db)


@router.patch("/{customer_id}", response_model=CustomerResponse)
def update_customer(
    customer_id: UUID,
    payload: CustomerUpdate,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    customer = _get_customer_or_404(customer_id, merchant.id, db)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(customer, field, value)
    db.commit()
    db.refresh(customer)
    return customer


@router.delete("/{customer_id}", status_code=204)
def deactivate_customer(
    customer_id: UUID,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """Soft-delete a customer. Existing transactions are preserved."""
    from datetime import datetime
    customer = _get_customer_or_404(customer_id, merchant.id, db)
    customer.is_deleted = True
    customer.deleted_at = datetime.utcnow()
    customer.is_active = False
    db.commit()


# ─── Payment Methods ──────────────────────────────────────────────────────────

@router.post("/{customer_id}/payment-methods", response_model=PaymentMethodResponse, status_code=201)
def add_payment_method(
    customer_id: UUID,
    payload: PaymentMethodCreate,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """Save a payment method (card, UPI, netbanking) for a customer."""
    customer = _get_customer_or_404(customer_id, merchant.id, db)

    # If setting as default, unset existing default
    if payload.is_default:
        db.query(CustomerPaymentMethod).filter(
            CustomerPaymentMethod.customer_id == customer.id,
            CustomerPaymentMethod.is_default == True,
        ).update({"is_default": False})

    pm = CustomerPaymentMethod(customer_id=customer.id, **payload.model_dump())
    db.add(pm)
    db.commit()
    db.refresh(pm)
    return pm


@router.get("/{customer_id}/payment-methods", response_model=List[PaymentMethodResponse])
def list_payment_methods(
    customer_id: UUID,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    customer = _get_customer_or_404(customer_id, merchant.id, db)
    return db.query(CustomerPaymentMethod).filter(
        CustomerPaymentMethod.customer_id == customer.id,
        CustomerPaymentMethod.is_active == True,
    ).all()


# ─── Wallet Topup ─────────────────────────────────────────────────────────────

@router.post("/{customer_id}/wallet/topup", response_model=dict)
def topup_wallet(
    customer_id: UUID,
    payload: WalletTopupRequest,
    db: Session = Depends(get_db),
    merchant: Merchant = Depends(get_merchant_from_api_key),
):
    """
    Add funds to a customer's wallet.
    Creates a WALLET_TOPUP transaction and a credit ledger entry.
    """
    from app.services.transaction_service import TransactionService
    from app.schemas.schemas import TransactionCreate
    from app.models.models import TransactionType

    customer = _get_customer_or_404(customer_id, merchant.id, db)

    if customer.wallet and customer.wallet.is_frozen:
        raise BusinessRuleError("Wallet is frozen. Contact support.")

    txn_payload = TransactionCreate(
        customer_id=customer_id,
        amount=payload.amount,
        transaction_type=TransactionType.WALLET_TOPUP,
        payment_method=payload.payment_method,
        description=payload.description or "Wallet topup",
    )

    txn = TransactionService.create_transaction(db, merchant, txn_payload)
    return {
        "transaction_id": str(txn.id),
        "reference_id": txn.reference_id,
        "amount": str(payload.amount),
        "new_balance": str(customer.wallet.balance),
    }


# ─── Internal helpers ─────────────────────────────────────────────────────────

def _get_customer_or_404(customer_id: UUID, merchant_id, db: Session) -> Customer:
    customer = db.query(Customer).filter(
        Customer.id == customer_id,
        Customer.merchant_id == merchant_id,
        Customer.is_deleted == False,
    ).first()
    if not customer:
        raise NotFoundError("Customer", str(customer_id))
    return customer
