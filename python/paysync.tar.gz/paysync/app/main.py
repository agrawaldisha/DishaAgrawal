"""
PaySync API — Main Application
================================
Entry point. Registers all routers, middleware, exception handlers.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError

from app.core.config import settings
from app.core.exceptions import (
    PaySyncException,
    paysync_exception_handler,
    validation_exception_handler,
    generic_exception_handler,
)
from app.middleware.middleware import RequestIDMiddleware, AuditLogMiddleware
from app.routers import auth, merchants, customers, transactions, settlements, admin

app = FastAPI(
    title=settings.APP_NAME,
    description="""
## PaySync — Multi-Tenant Payment Gateway API

A production-grade payment infrastructure platform.

### Authentication
- **Merchant API routes**: Pass your secret key in `X-API-Key` header
- **Admin/User routes**: Use `Authorization: Bearer <jwt_token>`

### Idempotency
For transaction creation, always pass an `idempotency_key` to safely retry without double charges.

### Webhooks
After every transaction status change, PaySync POSTs a signed event to your `webhook_url`.
Verify the `X-PaySync-Signature` header using HMAC-SHA256.
    """,
    version=settings.APP_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

# ─── Middleware (order matters — outermost runs first on request, last on response) ──

app.add_middleware(AuditLogMiddleware)
app.add_middleware(RequestIDMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Request-ID", "X-Response-Time"],
)

# ─── Exception Handlers ───────────────────────────────────────────────────────

app.add_exception_handler(PaySyncException, paysync_exception_handler)
app.add_exception_handler(RequestValidationError, validation_exception_handler)
app.add_exception_handler(Exception, generic_exception_handler)

# ─── Routers ─────────────────────────────────────────────────────────────────

API_PREFIX = "/api/v1"

app.include_router(auth.router,         prefix=API_PREFIX)
app.include_router(merchants.router,    prefix=API_PREFIX)
app.include_router(customers.router,    prefix=API_PREFIX)
app.include_router(transactions.router, prefix=API_PREFIX)
app.include_router(settlements.router,  prefix=API_PREFIX)
app.include_router(admin.router,        prefix=API_PREFIX)


# ─── Health & Info ────────────────────────────────────────────────────────────

@app.get("/health", tags=["System"])
def health_check():
    """Liveness probe — used by load balancers and Docker healthcheck."""
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "env": settings.APP_ENV,
    }


@app.get("/health/db", tags=["System"])
def db_health_check():
    """Readiness probe — checks DB connectivity."""
    from app.core.database import SessionLocal
    from sqlalchemy import text
    db = SessionLocal()
    try:
        db.execute(text("SELECT 1"))
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "database": str(e)}
    finally:
        db.close()


@app.get("/", tags=["System"])
def root():
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": "/docs",
        "health": "/health",
    }
