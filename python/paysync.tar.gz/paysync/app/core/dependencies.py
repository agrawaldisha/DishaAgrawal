"""
Auth Dependencies
=================
FastAPI Depends() functions for route protection.

Usage in a router:
    @router.get("/protected")
    def route(current_user: User = Depends(get_current_user)):
        ...

    @router.get("/admin-only")
    def route(current_user: User = Depends(require_super_admin)):
        ...

    @router.get("/merchant-api")
    def route(merchant: Merchant = Depends(get_merchant_from_api_key)):
        ...
"""

import hashlib
from typing import Optional
from uuid import UUID

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.exceptions import UnauthorizedError, ForbiddenError
from app.core.security import decode_token, hash_api_key
from app.models.models import User, MerchantAPIKey, Merchant, UserRole

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


# ─── JWT-based auth ───────────────────────────────────────────────────────────

def get_current_user(
    token: Optional[str] = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    if not token:
        raise UnauthorizedError("No authentication token provided")

    try:
        payload = decode_token(token)
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")
        if not user_id or token_type != "access":
            raise UnauthorizedError("Invalid token")
    except JWTError:
        raise UnauthorizedError("Token is invalid or expired")

    user = db.query(User).filter(
        User.id == user_id,
        User.is_deleted == False,
        User.is_active == True,
    ).first()

    if not user:
        raise UnauthorizedError("User not found or deactivated")

    return user


def get_current_active_user(user: User = Depends(get_current_user)) -> User:
    if not user.is_active:
        raise ForbiddenError("Account is deactivated")
    return user


# ─── Role guards ──────────────────────────────────────────────────────────────

def require_super_admin(user: User = Depends(get_current_active_user)) -> User:
    if user.role != UserRole.SUPER_ADMIN:
        raise ForbiddenError("Super admin access required")
    return user


def require_merchant_admin(user: User = Depends(get_current_active_user)) -> User:
    if user.role not in (UserRole.SUPER_ADMIN, UserRole.MERCHANT_ADMIN):
        raise ForbiddenError("Merchant admin access required")
    return user


def require_any_merchant_user(user: User = Depends(get_current_active_user)) -> User:
    if user.role not in (UserRole.SUPER_ADMIN, UserRole.MERCHANT_ADMIN, UserRole.MERCHANT_VIEWER):
        raise ForbiddenError("Merchant access required")
    return user


# ─── API Key-based auth (for merchant server-to-server calls) ────────────────

def get_merchant_from_api_key(
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
    db: Session = Depends(get_db),
) -> Merchant:
    """
    Merchants call the API using their secret key in the X-API-Key header.
    We hash the incoming key and look it up in the DB — we never store the raw key.
    """
    if not x_api_key:
        raise UnauthorizedError("X-API-Key header is required")

    key_hash = hash_api_key(x_api_key)

    api_key = db.query(MerchantAPIKey).filter(
        MerchantAPIKey.key_hash == key_hash,
        MerchantAPIKey.is_active == True,
    ).first()

    if not api_key:
        raise UnauthorizedError("Invalid API key")

    # Check merchant is active
    merchant = db.query(Merchant).filter(
        Merchant.id == api_key.merchant_id,
        Merchant.is_deleted == False,
    ).first()

    if not merchant:
        raise UnauthorizedError("Merchant not found")

    from app.models.models import MerchantStatus
    if merchant.status == MerchantStatus.SUSPENDED:
        raise ForbiddenError("Merchant account is suspended")

    # Update last_used_at (non-blocking — don't fail the request if this fails)
    try:
        from datetime import datetime
        api_key.last_used_at = datetime.utcnow()
        db.commit()
    except Exception:
        db.rollback()

    return merchant


# ─── Optional: check merchant owns the resource ───────────────────────────────

def verify_merchant_owns_customer(
    customer_id: UUID,
    merchant: Merchant = Depends(get_merchant_from_api_key),
    db: Session = Depends(get_db),
) -> None:
    """
    Multi-tenancy guard — ensures a merchant can only access their own customers.
    """
    from app.models.models import Customer
    customer = db.query(Customer).filter(
        Customer.id == customer_id,
        Customer.merchant_id == merchant.id,
    ).first()
    if not customer:
        raise ForbiddenError("You do not have access to this customer")
