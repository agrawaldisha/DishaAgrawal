"""
Pydantic Schemas
================
Separate schemas for:
  - Create (input from client)
  - Update (partial updates)
  - Response (what we send back — never expose hashed passwords or key hashes)
  - Internal (used between service layers)
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, List
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator
import re

from app.models.models import (
    MerchantStatus, KYCStatus, TransactionStatus, TransactionType,
    PaymentMethod, LedgerEntryType, WebhookStatus, UserRole, SettlementStatus
)


# ─── Base ─────────────────────────────────────────────────────────────────────

class BaseResponse(BaseModel):
    success: bool = True
    message: str = "OK"


class PaginationParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size


class PaginatedResponse(BaseModel):
    total: int
    page: int
    page_size: int
    total_pages: int
    items: list


# ─── Merchant ─────────────────────────────────────────────────────────────────

class MerchantCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=255)
    email: EmailStr
    phone: Optional[str] = Field(None, pattern=r"^\+?[1-9]\d{9,14}$")
    business_name: str = Field(..., min_length=2, max_length=255)
    business_type: Optional[str] = None
    website: Optional[str] = None
    webhook_url: Optional[str] = None


class MerchantUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=255)
    phone: Optional[str] = None
    business_type: Optional[str] = None
    website: Optional[str] = None
    webhook_url: Optional[str] = None
    settlement_account: Optional[str] = None
    settlement_ifsc: Optional[str] = None
    max_transaction_limit: Optional[Decimal] = Field(None, gt=0)
    daily_limit: Optional[Decimal] = Field(None, gt=0)


class MerchantResponse(BaseModel):
    id: UUID
    name: str
    email: str
    phone: Optional[str]
    business_name: str
    business_type: Optional[str]
    website: Optional[str]
    status: MerchantStatus
    kyc_status: KYCStatus
    webhook_url: Optional[str]
    max_transaction_limit: Decimal
    daily_limit: Decimal
    created_at: datetime

    model_config = {"from_attributes": True}


class MerchantAPIKeyCreate(BaseModel):
    name: Optional[str] = Field(None, max_length=100)


class MerchantAPIKeyResponse(BaseModel):
    id: UUID
    key_prefix: str
    name: Optional[str]
    is_active: bool
    last_used_at: Optional[datetime]
    expires_at: Optional[datetime]
    created_at: datetime
    raw_key: Optional[str] = None   # Only populated on creation, never again

    model_config = {"from_attributes": True}


# ─── User ─────────────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)
    full_name: str = Field(..., min_length=2, max_length=255)
    role: UserRole
    merchant_id: Optional[UUID] = None

    @field_validator("password")
    @classmethod
    def validate_password(cls, v):
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not re.search(r"[0-9]", v):
            raise ValueError("Password must contain at least one digit")
        return v


class UserResponse(BaseModel):
    id: UUID
    email: str
    full_name: str
    role: UserRole
    merchant_id: Optional[UUID]
    is_active: bool
    last_login_at: Optional[datetime]
    created_at: datetime

    model_config = {"from_attributes": True}


# ─── Auth ─────────────────────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int   # seconds


class RefreshRequest(BaseModel):
    refresh_token: str


# ─── Customer ─────────────────────────────────────────────────────────────────

class CustomerCreate(BaseModel):
    email: EmailStr
    phone: Optional[str] = Field(None, pattern=r"^\+?[1-9]\d{9,14}$")
    full_name: str = Field(..., min_length=2, max_length=255)


class CustomerUpdate(BaseModel):
    phone: Optional[str] = None
    full_name: Optional[str] = Field(None, min_length=2)


class WalletResponse(BaseModel):
    id: UUID
    balance: Decimal
    currency: str
    is_frozen: bool

    model_config = {"from_attributes": True}


class CustomerResponse(BaseModel):
    id: UUID
    merchant_id: UUID
    email: str
    phone: Optional[str]
    full_name: str
    is_active: bool
    wallet: Optional[WalletResponse]
    created_at: datetime

    model_config = {"from_attributes": True}


class PaymentMethodCreate(BaseModel):
    method_type: PaymentMethod
    display_name: str = Field(..., min_length=2, max_length=100)
    provider_token: Optional[str] = None
    is_default: bool = False


class PaymentMethodResponse(BaseModel):
    id: UUID
    method_type: PaymentMethod
    display_name: str
    is_default: bool
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


# ─── Transaction ──────────────────────────────────────────────────────────────

class TransactionCreate(BaseModel):
    customer_id: UUID
    amount: Decimal = Field(..., gt=0, decimal_places=2)
    currency: str = Field(default="INR", max_length=3)
    transaction_type: TransactionType = TransactionType.PAYMENT
    payment_method: PaymentMethod
    description: Optional[str] = Field(None, max_length=500)
    idempotency_key: Optional[str] = Field(None, max_length=128)
    metadata: Optional[dict] = None

    @field_validator("amount")
    @classmethod
    def validate_amount(cls, v):
        if v <= 0:
            raise ValueError("Amount must be greater than zero")
        if v > Decimal("10000000"):  # 1 crore max per transaction
            raise ValueError("Amount exceeds maximum transaction limit")
        return v

    @field_validator("currency")
    @classmethod
    def validate_currency(cls, v):
        allowed = {"INR", "USD", "EUR", "GBP", "SGD"}
        if v.upper() not in allowed:
            raise ValueError(f"Currency must be one of: {', '.join(allowed)}")
        return v.upper()


class RefundCreate(BaseModel):
    amount: Decimal = Field(..., gt=0, decimal_places=2)
    reason: Optional[str] = Field(None, max_length=500)
    idempotency_key: Optional[str] = Field(None, max_length=128)


class TransactionResponse(BaseModel):
    id: UUID
    reference_id: str
    merchant_id: UUID
    customer_id: UUID
    amount: Decimal
    currency: str
    transaction_type: TransactionType
    payment_method: PaymentMethod
    status: TransactionStatus
    description: Optional[str]
    provider_reference: Optional[str]
    failure_reason: Optional[str]
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class TransactionFilters(BaseModel):
    status: Optional[TransactionStatus] = None
    transaction_type: Optional[TransactionType] = None
    payment_method: Optional[PaymentMethod] = None
    customer_id: Optional[UUID] = None
    min_amount: Optional[Decimal] = None
    max_amount: Optional[Decimal] = None
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None
    reference_id: Optional[str] = None


# ─── Ledger ───────────────────────────────────────────────────────────────────

class LedgerEntryResponse(BaseModel):
    id: UUID
    entry_type: LedgerEntryType
    amount: Decimal
    balance_after: Decimal
    description: Optional[str]
    created_at: datetime

    model_config = {"from_attributes": True}


# ─── Webhook ──────────────────────────────────────────────────────────────────

class WebhookEventResponse(BaseModel):
    id: UUID
    event_type: str
    status: WebhookStatus
    attempt_count: int
    last_attempted_at: Optional[datetime]
    response_code: Optional[int]
    created_at: datetime

    model_config = {"from_attributes": True}


# ─── Settlement ───────────────────────────────────────────────────────────────

class SettlementResponse(BaseModel):
    id: UUID
    settlement_date: datetime
    gross_amount: Decimal
    fee_amount: Decimal
    tax_amount: Decimal
    net_amount: Decimal
    transaction_count: int
    status: SettlementStatus
    utr_number: Optional[str]
    created_at: datetime

    model_config = {"from_attributes": True}


# ─── Wallet topup ─────────────────────────────────────────────────────────────

class WalletTopupRequest(BaseModel):
    amount: Decimal = Field(..., gt=0, decimal_places=2)
    payment_method: PaymentMethod
    description: Optional[str] = None
