"""
PaySync ORM Models
==================
All tables use:
  - UUID primary keys (no guessable integer IDs in a payments system)
  - created_at / updated_at timestamps
  - is_deleted soft-delete flag (financial data is never hard-deleted)
  - Indexed foreign keys for query performance
"""

import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    Column, String, Boolean, DateTime, Numeric,
    ForeignKey, Enum, Text, Integer, Index, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum

from app.core.database import Base


# ─── Enums ────────────────────────────────────────────────────────────────────

class MerchantStatus(str, enum.Enum):
    PENDING_KYC = "pending_kyc"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    CLOSED = "closed"


class KYCStatus(str, enum.Enum):
    NOT_SUBMITTED = "not_submitted"
    SUBMITTED = "submitted"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    REJECTED = "rejected"


class TransactionStatus(str, enum.Enum):
    INITIATED = "initiated"
    PENDING = "pending"
    PROCESSING = "processing"
    SUCCESS = "success"
    FAILED = "failed"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"


class TransactionType(str, enum.Enum):
    PAYMENT = "payment"
    REFUND = "refund"
    SETTLEMENT = "settlement"
    WALLET_TOPUP = "wallet_topup"


class PaymentMethod(str, enum.Enum):
    UPI = "upi"
    CARD = "card"
    NETBANKING = "netbanking"
    WALLET = "wallet"
    NEFT = "neft"


class LedgerEntryType(str, enum.Enum):
    DEBIT = "debit"
    CREDIT = "credit"


class WebhookStatus(str, enum.Enum):
    PENDING = "pending"
    DELIVERED = "delivered"
    FAILED = "failed"
    RETRYING = "retrying"


class UserRole(str, enum.Enum):
    SUPER_ADMIN = "super_admin"
    MERCHANT_ADMIN = "merchant_admin"
    MERCHANT_VIEWER = "merchant_viewer"
    CUSTOMER = "customer"


class SettlementStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


# ─── Mixins ───────────────────────────────────────────────────────────────────

class TimestampMixin:
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)


class SoftDeleteMixin:
    is_deleted = Column(Boolean, default=False, nullable=False)
    deleted_at = Column(DateTime(timezone=True), nullable=True)


# ─── Models ───────────────────────────────────────────────────────────────────

class Merchant(Base, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "merchants"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    phone = Column(String(20), nullable=True)
    business_name = Column(String(255), nullable=False)
    business_type = Column(String(100), nullable=True)         # e.g. ecommerce, saas, food
    website = Column(String(500), nullable=True)
    status = Column(Enum(MerchantStatus), default=MerchantStatus.PENDING_KYC, nullable=False)
    kyc_status = Column(Enum(KYCStatus), default=KYCStatus.NOT_SUBMITTED, nullable=False)
    webhook_url = Column(String(500), nullable=True)           # Where we POST transaction events
    settlement_account = Column(String(100), nullable=True)    # Bank account for payouts
    settlement_ifsc = Column(String(20), nullable=True)
    max_transaction_limit = Column(Numeric(15, 2), default=100000.00)  # Per-txn limit in INR
    daily_limit = Column(Numeric(15, 2), default=1000000.00)           # Daily volume limit

    # Relationships
    api_keys = relationship("MerchantAPIKey", back_populates="merchant")
    customers = relationship("Customer", back_populates="merchant")
    transactions = relationship("Transaction", back_populates="merchant")
    settlements = relationship("Settlement", back_populates="merchant")
    users = relationship("User", back_populates="merchant")

    __table_args__ = (
        Index("ix_merchants_status", "status"),
        Index("ix_merchants_kyc_status", "kyc_status"),
    )


class MerchantAPIKey(Base, TimestampMixin):
    __tablename__ = "merchant_api_keys"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_id = Column(UUID(as_uuid=True), ForeignKey("merchants.id"), nullable=False, index=True)
    key_hash = Column(String(64), unique=True, nullable=False, index=True)  # SHA-256 of raw key
    key_prefix = Column(String(20), nullable=False)                          # First 12 chars for display
    name = Column(String(100), nullable=True)                                # e.g. "Production key"
    is_active = Column(Boolean, default=True, nullable=False)
    last_used_at = Column(DateTime(timezone=True), nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=True)

    merchant = relationship("Merchant", back_populates="api_keys")


class User(Base, TimestampMixin, SoftDeleteMixin):
    """Internal users — PaySync admins and merchant staff."""
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_id = Column(UUID(as_uuid=True), ForeignKey("merchants.id"), nullable=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    last_login_at = Column(DateTime(timezone=True), nullable=True)

    merchant = relationship("Merchant", back_populates="users")


class Customer(Base, TimestampMixin, SoftDeleteMixin):
    """End users who make payments through a merchant's integration."""
    __tablename__ = "customers"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_id = Column(UUID(as_uuid=True), ForeignKey("merchants.id"), nullable=False, index=True)
    email = Column(String(255), nullable=False, index=True)
    phone = Column(String(20), nullable=True)
    full_name = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    # Relationships
    merchant = relationship("Merchant", back_populates="customers")
    wallet = relationship("Wallet", back_populates="customer", uselist=False)
    transactions = relationship("Transaction", back_populates="customer")
    payment_methods = relationship("CustomerPaymentMethod", back_populates="customer")

    __table_args__ = (
        UniqueConstraint("merchant_id", "email", name="uq_customer_merchant_email"),
        Index("ix_customers_merchant_phone", "merchant_id", "phone"),
    )


class Wallet(Base, TimestampMixin):
    """One wallet per customer. Balance is always in paisa (smallest unit)."""
    __tablename__ = "wallets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    customer_id = Column(UUID(as_uuid=True), ForeignKey("customers.id"), unique=True, nullable=False)
    balance = Column(Numeric(15, 2), default=0.00, nullable=False)   # In INR
    currency = Column(String(3), default="INR", nullable=False)
    is_frozen = Column(Boolean, default=False, nullable=False)        # Freeze on fraud suspicion

    customer = relationship("Customer", back_populates="wallet")
    ledger_entries = relationship("LedgerEntry", back_populates="wallet")


class CustomerPaymentMethod(Base, TimestampMixin):
    """Saved payment methods — cards, UPI VPAs, bank accounts."""
    __tablename__ = "customer_payment_methods"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    customer_id = Column(UUID(as_uuid=True), ForeignKey("customers.id"), nullable=False, index=True)
    method_type = Column(Enum(PaymentMethod), nullable=False)
    display_name = Column(String(100), nullable=False)   # "HDFC ****4242" or "user@upi"
    provider_token = Column(String(500), nullable=True)  # Encrypted token from payment provider
    is_default = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)

    customer = relationship("Customer", back_populates="payment_methods")


class Transaction(Base, TimestampMixin):
    """
    Core financial record. NEVER update amount or type after creation.
    For corrections, create a new REFUND transaction.
    """
    __tablename__ = "transactions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    reference_id = Column(String(64), unique=True, nullable=False, index=True)  # Human-readable TXN ref
    merchant_id = Column(UUID(as_uuid=True), ForeignKey("merchants.id"), nullable=False, index=True)
    customer_id = Column(UUID(as_uuid=True), ForeignKey("customers.id"), nullable=False, index=True)
    amount = Column(Numeric(15, 2), nullable=False)
    currency = Column(String(3), default="INR", nullable=False)
    transaction_type = Column(Enum(TransactionType), nullable=False)
    payment_method = Column(Enum(PaymentMethod), nullable=False)
    status = Column(Enum(TransactionStatus), default=TransactionStatus.INITIATED, nullable=False)
    description = Column(Text, nullable=True)
    idempotency_key = Column(String(128), unique=True, nullable=True, index=True)
    provider_reference = Column(String(255), nullable=True)  # Razorpay/Stripe TXN ID
    failure_reason = Column(Text, nullable=True)
    metadata = Column(Text, nullable=True)          # JSON string for custom merchant data
    parent_transaction_id = Column(UUID(as_uuid=True), ForeignKey("transactions.id"), nullable=True)  # For refunds

    # Relationships
    merchant = relationship("Merchant", back_populates="transactions")
    customer = relationship("Customer", back_populates="transactions")
    ledger_entries = relationship("LedgerEntry", back_populates="transaction")
    webhook_events = relationship("WebhookEvent", back_populates="transaction")
    child_transactions = relationship("Transaction", foreign_keys=[parent_transaction_id])

    __table_args__ = (
        Index("ix_transactions_merchant_status", "merchant_id", "status"),
        Index("ix_transactions_merchant_created", "merchant_id", "created_at"),
        Index("ix_transactions_customer_created", "customer_id", "created_at"),
        Index("ix_transactions_status", "status"),
    )


class LedgerEntry(Base, TimestampMixin):
    """
    Immutable double-entry ledger. Every rupee movement creates two entries.
    This is the source of truth for balances — never update, only append.
    """
    __tablename__ = "ledger_entries"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    wallet_id = Column(UUID(as_uuid=True), ForeignKey("wallets.id"), nullable=False, index=True)
    transaction_id = Column(UUID(as_uuid=True), ForeignKey("transactions.id"), nullable=False, index=True)
    entry_type = Column(Enum(LedgerEntryType), nullable=False)
    amount = Column(Numeric(15, 2), nullable=False)
    balance_after = Column(Numeric(15, 2), nullable=False)  # Snapshot of balance after this entry
    description = Column(Text, nullable=True)

    wallet = relationship("Wallet", back_populates="ledger_entries")
    transaction = relationship("Transaction", back_populates="ledger_entries")


class WebhookEvent(Base, TimestampMixin):
    """Every status change fires a webhook to the merchant's callback URL."""
    __tablename__ = "webhook_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_id = Column(UUID(as_uuid=True), ForeignKey("merchants.id"), nullable=False, index=True)
    transaction_id = Column(UUID(as_uuid=True), ForeignKey("transactions.id"), nullable=False, index=True)
    event_type = Column(String(100), nullable=False)         # e.g. "transaction.success"
    payload = Column(Text, nullable=False)                   # JSON payload sent to merchant
    status = Column(Enum(WebhookStatus), default=WebhookStatus.PENDING, nullable=False)
    attempt_count = Column(Integer, default=0, nullable=False)
    last_attempted_at = Column(DateTime(timezone=True), nullable=True)
    next_retry_at = Column(DateTime(timezone=True), nullable=True)
    response_code = Column(Integer, nullable=True)           # HTTP status from merchant's server
    response_body = Column(Text, nullable=True)

    transaction = relationship("Transaction", back_populates="webhook_events")

    __table_args__ = (
        Index("ix_webhook_events_status", "status"),
        Index("ix_webhook_events_next_retry", "next_retry_at"),
    )


class Settlement(Base, TimestampMixin):
    """Daily batch payout from PaySync to merchant's bank account."""
    __tablename__ = "settlements"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_id = Column(UUID(as_uuid=True), ForeignKey("merchants.id"), nullable=False, index=True)
    settlement_date = Column(DateTime(timezone=True), nullable=False)
    gross_amount = Column(Numeric(15, 2), nullable=False)
    fee_amount = Column(Numeric(15, 2), default=0.00)
    tax_amount = Column(Numeric(15, 2), default=0.00)
    net_amount = Column(Numeric(15, 2), nullable=False)
    transaction_count = Column(Integer, nullable=False)
    status = Column(Enum(SettlementStatus), default=SettlementStatus.PENDING, nullable=False)
    utr_number = Column(String(50), nullable=True)   # Unique Transaction Reference from bank

    merchant = relationship("Merchant", back_populates="settlements")


class AuditLog(Base, TimestampMixin):
    """
    Immutable audit trail. Every sensitive action is recorded here.
    Required for PCI-DSS and RBI compliance.
    """
    __tablename__ = "audit_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    actor_id = Column(UUID(as_uuid=True), nullable=True)     # User or system that performed action
    actor_type = Column(String(50), nullable=False)          # "user", "merchant_api", "system"
    merchant_id = Column(UUID(as_uuid=True), nullable=True, index=True)
    action = Column(String(200), nullable=False)             # e.g. "transaction.create"
    resource_type = Column(String(100), nullable=False)      # e.g. "Transaction"
    resource_id = Column(String(100), nullable=True)
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(Text, nullable=True)
    old_values = Column(Text, nullable=True)                 # JSON snapshot before change
    new_values = Column(Text, nullable=True)                 # JSON snapshot after change
    success = Column(Boolean, default=True, nullable=False)
    failure_reason = Column(Text, nullable=True)

    __table_args__ = (
        Index("ix_audit_logs_actor", "actor_id"),
        Index("ix_audit_logs_resource", "resource_type", "resource_id"),
        Index("ix_audit_logs_merchant_created", "merchant_id", "created_at"),
    )
