# PaySync — Multi-Tenant Payment Gateway API

Production-grade FastAPI + PostgreSQL payment infrastructure platform.

---

## Quick Start

### 1. Clone and configure

```bash
cd paysync
cp .env .env.local   # edit your Postgres credentials
```

Edit `.env` and set:
```
DATABASE_URL=postgresql://youruser:yourpassword@localhost:5432/paysync
SECRET_KEY=your-minimum-32-char-secret-key-here
```

### 2. Install dependencies

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Create database and run migrations

```bash
# Create the DB first (in psql)
createdb paysync

# Run migrations
alembic upgrade head
```

### 4. Start the server

```bash
uvicorn app.main:app --reload --port 8000
```

Open **http://localhost:8000/docs** for the interactive Swagger UI.

---

## Docker (everything in one command)

```bash
docker-compose up --build
```

This starts Postgres + Redis + the API. Migrations run automatically.

---

## Running Tests

```bash
pytest tests/ -v
```

Tests use SQLite — no Postgres needed.

---

## API Walkthrough (curl examples)

### Step 1 — Create a super admin user

```bash
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@paysync.com",
    "password": "Admin@1234",
    "full_name": "Super Admin",
    "role": "super_admin"
  }'
```

### Step 2 — Login and get JWT token

```bash
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@paysync.com", "password": "Admin@1234"}'

# Save the access_token from the response
export TOKEN="eyJ..."
```

### Step 3 — Onboard a merchant

```bash
curl -X POST http://localhost:8000/api/v1/merchants \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Swiggy Finance",
    "email": "finance@swiggy.com",
    "business_name": "Bundl Technologies Pvt Ltd",
    "business_type": "food_delivery",
    "webhook_url": "https://your-server.com/webhooks/paysync"
  }'

# Save the merchant id
export MERCHANT_ID="uuid-from-response"
```

### Step 4 — Approve KYC (so merchant can transact)

```bash
curl -X PATCH "http://localhost:8000/api/v1/merchants/$MERCHANT_ID/kyc?kyc_status=approved" \
  -H "Authorization: Bearer $TOKEN"
```

### Step 5 — Generate API key for the merchant

```bash
curl -X POST "http://localhost:8000/api/v1/merchants/$MERCHANT_ID/api-keys" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "Production key"}'

# Save the raw_key — shown ONLY once
export API_KEY="sk_live_..."
```

### Step 6 — Register a customer (using merchant API key)

```bash
curl -X POST http://localhost:8000/api/v1/customers \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john.doe@gmail.com",
    "full_name": "John Doe",
    "phone": "+919876543210"
  }'

export CUSTOMER_ID="uuid-from-response"
```

### Step 7 — Top up customer wallet

```bash
curl -X POST "http://localhost:8000/api/v1/customers/$CUSTOMER_ID/wallet/topup" \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": "5000.00",
    "payment_method": "netbanking",
    "description": "Wallet load via HDFC"
  }'
```

### Step 8 — Create a payment transaction

```bash
curl -X POST http://localhost:8000/api/v1/transactions \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": "'"$CUSTOMER_ID"'",
    "amount": "499.00",
    "payment_method": "wallet",
    "description": "Swiggy order #ORD998877",
    "idempotency_key": "ord-998877-pay-attempt-1",
    "metadata": {"order_id": "ORD998877", "restaurant": "Burger King"}
  }'

export TXN_ID="uuid-from-response"
```

### Step 9 — Issue a partial refund

```bash
curl -X POST "http://localhost:8000/api/v1/transactions/$TXN_ID/refund" \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": "199.00",
    "reason": "Item unavailable — partial refund",
    "idempotency_key": "ord-998877-refund-1"
  }'
```

### Step 10 — View ledger entries (audit trail)

```bash
curl "http://localhost:8000/api/v1/transactions/$TXN_ID/ledger" \
  -H "X-API-Key: $API_KEY"
```

### Step 11 — Transaction dashboard with filters

```bash
curl "http://localhost:8000/api/v1/transactions?status=success&payment_method=wallet&page=1&page_size=10" \
  -H "X-API-Key: $API_KEY"

curl "http://localhost:8000/api/v1/transactions/summary" \
  -H "X-API-Key: $API_KEY"
```

### Step 12 — Trigger settlement (admin)

```bash
curl -X POST "http://localhost:8000/api/v1/settlements/trigger/$MERCHANT_ID" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Project Structure

```
paysync/
├── app/
│   ├── main.py              ← FastAPI app, middleware, routers
│   ├── core/
│   │   ├── config.py        ← Pydantic Settings (env vars)
│   │   ├── database.py      ← SQLAlchemy engine + session
│   │   ├── security.py      ← JWT, bcrypt, API key generation
│   │   ├── dependencies.py  ← FastAPI Depends() auth guards
│   │   └── exceptions.py    ← Custom exceptions + handlers
│   ├── models/
│   │   └── models.py        ← All SQLAlchemy ORM models
│   ├── schemas/
│   │   └── schemas.py       ← All Pydantic request/response schemas
│   ├── routers/
│   │   ├── auth.py          ← Login, refresh, register
│   │   ├── merchants.py     ← Merchant CRUD + API keys
│   │   ├── customers.py     ← Customer + wallet + payment methods
│   │   ├── transactions.py  ← Payment, refund, ledger, webhooks
│   │   ├── settlements.py   ← Daily settlement batches
│   │   └── admin.py         ← Platform stats, audit logs
│   ├── services/
│   │   ├── transaction_service.py  ← Core payment logic + idempotency
│   │   └── webhook_service.py      ← HMAC signing + delivery + retry
│   └── middleware/
│       └── middleware.py    ← Request ID + Audit log middleware
├── alembic/                 ← DB migrations
├── tests/
│   └── test_paysync.py      ← Full test suite (30+ tests)
├── .env                     ← Your config (never commit this)
├── alembic.ini
├── docker-compose.yml
├── Dockerfile
└── requirements.txt
```

---

## FastAPI Concepts Covered

| Concept | Where to find it |
|---|---|
| Routers + prefixes | `app/main.py` + every router file |
| Pydantic models | `app/schemas/schemas.py` |
| Field validators | `TransactionCreate`, `UserCreate` in schemas |
| SQLAlchemy ORM | `app/models/models.py` |
| Alembic migrations | `alembic/env.py` |
| Depends() injection | `app/core/dependencies.py` |
| OAuth2 + JWT | `app/core/security.py`, `app/routers/auth.py` |
| API Key auth | `app/core/dependencies.py` → `get_merchant_from_api_key` |
| Role-based access | `require_super_admin`, `require_merchant_admin` |
| BackgroundTasks | `app/routers/transactions.py` |
| Custom exceptions | `app/core/exceptions.py` |
| Middleware | `app/middleware/middleware.py` |
| Pagination + filters | `app/routers/transactions.py` → `list_transactions` |
| Row-level locking | `app/services/transaction_service.py` → `with_for_update()` |
| Idempotency | `TransactionService.create_transaction` |
| Soft deletes | `SoftDeleteMixin` on Merchant, Customer, User |
| Audit trail | `AuditLog` model + `AuditLogMiddleware` |
| Testing | `tests/test_paysync.py` — TestClient + SQLite fixture |
| Docker | `Dockerfile` + `docker-compose.yml` |
