"""
PaySync Test Suite
==================
Uses an in-memory SQLite DB for speed (no Postgres needed for tests).
TestClient from FastAPI/Starlette makes real HTTP calls through the app.

Run:
    pytest tests/ -v
    pytest tests/ -v --tb=short -q      # quieter output
    pytest tests/test_transactions.py   # single file
"""

import pytest
from decimal import Decimal
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.core.database import get_db, Base
from app.core.security import hash_password, generate_api_key, hash_api_key
from app.models.models import (
    User, Merchant, MerchantAPIKey, Customer, Wallet,
    UserRole, MerchantStatus, KYCStatus,
)

# ─── Test DB setup ────────────────────────────────────────────────────────────

SQLITE_URL = "sqlite:///./test.db"

test_engine = create_engine(
    SQLITE_URL,
    connect_args={"check_same_thread": False},
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(autouse=True)
def setup_db():
    """Create all tables before each test, drop after."""
    Base.metadata.create_all(bind=test_engine)
    yield
    Base.metadata.drop_all(bind=test_engine)


@pytest.fixture
def db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture
def client():
    return TestClient(app)


# ─── Seed helpers ─────────────────────────────────────────────────────────────

@pytest.fixture
def super_admin(db):
    user = User(
        email="admin@paysync.com",
        hashed_password=hash_password("Admin@1234"),
        full_name="Super Admin",
        role=UserRole.SUPER_ADMIN,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@pytest.fixture
def admin_token(client, super_admin):
    resp = client.post("/api/v1/auth/login", json={
        "email": "admin@paysync.com",
        "password": "Admin@1234",
    })
    return resp.json()["access_token"]


@pytest.fixture
def active_merchant(db):
    merchant = Merchant(
        name="Test Merchant",
        email="merchant@test.com",
        business_name="Test Corp",
        status=MerchantStatus.ACTIVE,
        kyc_status=KYCStatus.APPROVED,
        max_transaction_limit=Decimal("100000"),
        daily_limit=Decimal("1000000"),
    )
    db.add(merchant)
    db.commit()
    db.refresh(merchant)
    return merchant


@pytest.fixture
def merchant_api_key(db, active_merchant):
    raw_key, key_hash = generate_api_key()
    api_key = MerchantAPIKey(
        merchant_id=active_merchant.id,
        key_hash=key_hash,
        key_prefix=raw_key[:12],
        name="Test key",
    )
    db.add(api_key)
    db.commit()
    return raw_key


@pytest.fixture
def api_headers(merchant_api_key):
    return {"X-API-Key": merchant_api_key}


@pytest.fixture
def customer_with_wallet(db, active_merchant):
    customer = Customer(
        merchant_id=active_merchant.id,
        email="customer@test.com",
        full_name="Test Customer",
        phone="+919876543210",
    )
    db.add(customer)
    db.flush()

    wallet = Wallet(
        customer_id=customer.id,
        balance=Decimal("5000.00"),
        currency="INR",
    )
    db.add(wallet)
    db.commit()
    db.refresh(customer)
    return customer


# ─── Auth Tests ───────────────────────────────────────────────────────────────

class TestAuth:
    def test_login_success(self, client, super_admin):
        resp = client.post("/api/v1/auth/login", json={
            "email": "admin@paysync.com",
            "password": "Admin@1234",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"

    def test_login_wrong_password(self, client, super_admin):
        resp = client.post("/api/v1/auth/login", json={
            "email": "admin@paysync.com",
            "password": "WrongPassword",
        })
        assert resp.status_code == 401
        assert resp.json()["error"]["code"] == "UNAUTHORIZED"

    def test_login_nonexistent_user(self, client):
        resp = client.post("/api/v1/auth/login", json={
            "email": "nobody@paysync.com",
            "password": "Whatever@1",
        })
        assert resp.status_code == 401

    def test_refresh_token(self, client, super_admin, admin_token):
        # First login to get refresh token
        login_resp = client.post("/api/v1/auth/login", json={
            "email": "admin@paysync.com",
            "password": "Admin@1234",
        })
        refresh_token = login_resp.json()["refresh_token"]

        resp = client.post("/api/v1/auth/refresh", json={"refresh_token": refresh_token})
        assert resp.status_code == 200
        assert "access_token" in resp.json()

    def test_register_user(self, client):
        resp = client.post("/api/v1/auth/register", json={
            "email": "newadmin@paysync.com",
            "password": "NewAdmin@1234",
            "full_name": "New Admin",
            "role": "super_admin",
        })
        assert resp.status_code == 201
        assert resp.json()["email"] == "newadmin@paysync.com"


# ─── Merchant Tests ───────────────────────────────────────────────────────────

class TestMerchants:
    def test_create_merchant(self, client, admin_token):
        resp = client.post(
            "/api/v1/merchants",
            json={
                "name": "Swiggy",
                "email": "finance@swiggy.com",
                "business_name": "Bundl Technologies",
                "business_type": "food_delivery",
                "webhook_url": "https://swiggy.com/webhooks/paysync",
            },
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["email"] == "finance@swiggy.com"
        assert data["status"] == "pending_kyc"
        assert data["kyc_status"] == "not_submitted"

    def test_create_duplicate_merchant(self, client, admin_token, active_merchant):
        resp = client.post(
            "/api/v1/merchants",
            json={
                "name": "Dupe",
                "email": "merchant@test.com",   # same as active_merchant
                "business_name": "Dupe Corp",
            },
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert resp.status_code == 409
        assert resp.json()["error"]["code"] == "CONFLICT"

    def test_create_merchant_requires_admin(self, client):
        resp = client.post("/api/v1/merchants", json={
            "name": "X", "email": "x@x.com", "business_name": "X Corp"
        })
        assert resp.status_code == 401

    def test_generate_api_key(self, client, admin_token, active_merchant):
        resp = client.post(
            f"/api/v1/merchants/{active_merchant.id}/api-keys",
            json={"name": "Production key"},
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert "raw_key" in data
        assert data["raw_key"].startswith("sk_live_")
        # raw_key only returned once
        assert len(data["raw_key"]) > 12


# ─── Customer Tests ───────────────────────────────────────────────────────────

class TestCustomers:
    def test_create_customer(self, client, api_headers):
        resp = client.post(
            "/api/v1/customers",
            json={
                "email": "john@example.com",
                "full_name": "John Doe",
                "phone": "+919876543210",
            },
            headers=api_headers,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["email"] == "john@example.com"
        assert data["wallet"]["balance"] == "0.00"
        assert data["wallet"]["currency"] == "INR"

    def test_create_duplicate_customer_same_merchant(self, client, api_headers, customer_with_wallet):
        resp = client.post(
            "/api/v1/customers",
            json={"email": "customer@test.com", "full_name": "Dup"},
            headers=api_headers,
        )
        assert resp.status_code == 409

    def test_list_customers_with_search(self, client, api_headers, customer_with_wallet):
        resp = client.get(
            "/api/v1/customers?search=Test",
            headers=api_headers,
        )
        assert resp.status_code == 200
        assert len(resp.json()) == 1

    def test_search_no_results(self, client, api_headers, customer_with_wallet):
        resp = client.get("/api/v1/customers?search=nobody", headers=api_headers)
        assert resp.status_code == 200
        assert len(resp.json()) == 0

    def test_update_customer(self, client, api_headers, customer_with_wallet):
        resp = client.patch(
            f"/api/v1/customers/{customer_with_wallet.id}",
            json={"full_name": "Updated Name"},
            headers=api_headers,
        )
        assert resp.status_code == 200
        assert resp.json()["full_name"] == "Updated Name"

    def test_add_payment_method(self, client, api_headers, customer_with_wallet):
        resp = client.post(
            f"/api/v1/customers/{customer_with_wallet.id}/payment-methods",
            json={
                "method_type": "upi",
                "display_name": "john@okicici",
                "is_default": True,
            },
            headers=api_headers,
        )
        assert resp.status_code == 201
        assert resp.json()["method_type"] == "upi"


# ─── Transaction Tests ────────────────────────────────────────────────────────

class TestTransactions:
    def test_create_payment_success(self, client, api_headers, customer_with_wallet):
        resp = client.post(
            "/api/v1/transactions",
            json={
                "customer_id": str(customer_with_wallet.id),
                "amount": "500.00",
                "payment_method": "wallet",
                "description": "Order #12345",
                "idempotency_key": "order-12345-attempt-1",
            },
            headers=api_headers,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "success"
        assert data["amount"] == "500.00"
        assert data["reference_id"].startswith("TXN")

    def test_idempotency_returns_same_transaction(self, client, api_headers, customer_with_wallet):
        payload = {
            "customer_id": str(customer_with_wallet.id),
            "amount": "200.00",
            "payment_method": "upi",
            "idempotency_key": "unique-key-abc123",
        }
        resp1 = client.post("/api/v1/transactions", json=payload, headers=api_headers)
        resp2 = client.post("/api/v1/transactions", json=payload, headers=api_headers)

        assert resp1.status_code == 201
        assert resp2.status_code == 201
        # Same transaction returned — not a double charge
        assert resp1.json()["id"] == resp2.json()["id"]

    def test_insufficient_balance(self, client, api_headers, customer_with_wallet):
        resp = client.post(
            "/api/v1/transactions",
            json={
                "customer_id": str(customer_with_wallet.id),
                "amount": "99999.00",   # More than wallet balance of 5000
                "payment_method": "wallet",
            },
            headers=api_headers,
        )
        assert resp.status_code == 422
        assert "Insufficient" in resp.json()["error"]["message"]

    def test_exceeds_merchant_limit(self, client, api_headers, customer_with_wallet):
        resp = client.post(
            "/api/v1/transactions",
            json={
                "customer_id": str(customer_with_wallet.id),
                "amount": "200000.00",   # Exceeds max_transaction_limit of 100000
                "payment_method": "wallet",
            },
            headers=api_headers,
        )
        assert resp.status_code == 422
        assert "limit" in resp.json()["error"]["message"].lower()

    def test_refund_transaction(self, client, api_headers, customer_with_wallet):
        # Create payment first
        txn_resp = client.post(
            "/api/v1/transactions",
            json={
                "customer_id": str(customer_with_wallet.id),
                "amount": "1000.00",
                "payment_method": "upi",
            },
            headers=api_headers,
        )
        txn_id = txn_resp.json()["id"]

        # Refund partial amount
        refund_resp = client.post(
            f"/api/v1/transactions/{txn_id}/refund",
            json={"amount": "400.00", "reason": "Customer request"},
            headers=api_headers,
        )
        assert refund_resp.status_code == 201
        assert refund_resp.json()["transaction_type"] == "refund"
        assert refund_resp.json()["amount"] == "400.00"

    def test_refund_exceeds_original(self, client, api_headers, customer_with_wallet):
        txn_resp = client.post(
            "/api/v1/transactions",
            json={
                "customer_id": str(customer_with_wallet.id),
                "amount": "300.00",
                "payment_method": "card",
            },
            headers=api_headers,
        )
        txn_id = txn_resp.json()["id"]

        refund_resp = client.post(
            f"/api/v1/transactions/{txn_id}/refund",
            json={"amount": "999.00"},   # More than original 300
            headers=api_headers,
        )
        assert refund_resp.status_code == 422

    def test_list_transactions_with_filters(self, client, api_headers, customer_with_wallet):
        # Create two transactions
        for amount in ["100.00", "200.00"]:
            client.post(
                "/api/v1/transactions",
                json={
                    "customer_id": str(customer_with_wallet.id),
                    "amount": amount,
                    "payment_method": "wallet",
                },
                headers=api_headers,
            )

        # Filter by status
        resp = client.get(
            "/api/v1/transactions?status=success&sort_by=amount&sort_order=asc",
            headers=api_headers,
        )
        assert resp.status_code == 200
        txns = resp.json()
        assert len(txns) == 2
        assert float(txns[0]["amount"]) < float(txns[1]["amount"])

    def test_transaction_ledger_entries(self, client, api_headers, customer_with_wallet):
        txn_resp = client.post(
            "/api/v1/transactions",
            json={
                "customer_id": str(customer_with_wallet.id),
                "amount": "750.00",
                "payment_method": "netbanking",
            },
            headers=api_headers,
        )
        txn_id = txn_resp.json()["id"]

        ledger_resp = client.get(
            f"/api/v1/transactions/{txn_id}/ledger",
            headers=api_headers,
        )
        assert ledger_resp.status_code == 200
        entries = ledger_resp.json()
        assert len(entries) == 1
        assert entries[0]["entry_type"] == "debit"
        assert entries[0]["amount"] == "750.00"
        assert entries[0]["balance_after"] == "4250.00"   # 5000 - 750

    def test_transaction_summary(self, client, api_headers, customer_with_wallet):
        client.post(
            "/api/v1/transactions",
            json={
                "customer_id": str(customer_with_wallet.id),
                "amount": "500.00",
                "payment_method": "upi",
            },
            headers=api_headers,
        )
        resp = client.get("/api/v1/transactions/summary", headers=api_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_count"] == 1
        assert data["total_volume"] == "500.00"

    def test_kyc_gate_blocks_transaction(self, client, db):
        # Create a merchant without KYC approval
        from app.models.models import KYCStatus, MerchantStatus
        merchant = Merchant(
            name="No KYC",
            email="nokyc@test.com",
            business_name="No KYC Corp",
            status=MerchantStatus.ACTIVE,
            kyc_status=KYCStatus.SUBMITTED,   # Not approved
            max_transaction_limit=Decimal("100000"),
            daily_limit=Decimal("1000000"),
        )
        db.add(merchant)
        db.flush()

        raw_key, key_hash = generate_api_key()
        db.add(MerchantAPIKey(
            merchant_id=merchant.id,
            key_hash=key_hash,
            key_prefix=raw_key[:12],
        ))
        customer = Customer(
            merchant_id=merchant.id,
            email="c@c.com",
            full_name="C",
        )
        db.add(customer)
        db.flush()
        db.add(Wallet(customer_id=customer.id, balance=Decimal("1000")))
        db.commit()

        resp = client.post(
            "/api/v1/transactions",
            json={
                "customer_id": str(customer.id),
                "amount": "100.00",
                "payment_method": "upi",
            },
            headers={"X-API-Key": raw_key},
        )
        assert resp.status_code == 422
        assert "KYC" in resp.json()["error"]["message"]


# ─── System Tests ─────────────────────────────────────────────────────────────

class TestSystem:
    def test_health_endpoint(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "healthy"

    def test_root_endpoint(self, client):
        resp = client.get("/")
        assert resp.status_code == 200

    def test_request_id_header_present(self, client):
        resp = client.get("/health")
        assert "X-Request-ID" in resp.headers
        assert "X-Response-Time" in resp.headers

    def test_validation_error_format(self, client):
        resp = client.post("/api/v1/auth/login", json={"email": "not-an-email", "password": ""})
        assert resp.status_code == 422
        error = resp.json()["error"]
        assert error["code"] == "VALIDATION_ERROR"
        assert isinstance(error["detail"], list)

    def test_unknown_route_404(self, client):
        resp = client.get("/api/v1/doesnotexist")
        assert resp.status_code == 404

    def test_api_key_required_for_merchant_routes(self, client):
        resp = client.get("/api/v1/customers")
        assert resp.status_code == 401
